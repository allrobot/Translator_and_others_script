/*
Title: Localization
Author: DKPlugins
Site: https://dk-plugins.ru
E-mail: kuznetsovdenis96@gmail.com
Version: 5.5.7
Release: 10.08.2023
First release: 28.08.2016
*/

/*ru
Название: Локализация
Автор: DKPlugins
Сайт: https://dk-plugins.ru
E-mail: kuznetsovdenis96@gmail.com
Версия: 5.5.7
Релиз: 10.08.2023
Первый релиз: 28.08.2016
*/

/*:
 * @plugindesc v.5.5.7 [MV] 给游戏增加多语言切换.
 * @author DKPlugins
 * @url https://dk-plugins.ru
 * @target MV
 * @base DKTools
 * @orderAfter DKTools
 * @help

 ### 关于插件 ###
 Title: DKTools_Localization
 Author: DKPlugins
 Site: https://dk-plugins.ru
 Version: 5.5.7
 Release: 10.08.2023
 First release: 28.08.2016

 ###===========================================================================
 ## 需求和依赖
 ###===========================================================================
 DKTools版本11.2.5或以上，注意，不要下错MZ的DKTools了，MZ的DKTools版本1.3.6
 MV的DKTools_Localization插件不支持MZ的DKTools

 ###===========================================================================
 ## 已知问题
 ###===========================================================================
 1. 用于更改字体大小的特殊消息字符\{和\}不起作用
 解决方案:使用额外的特殊字符
 \MFS - Decrease font size (analogue \})
 \MFB - Increase font size (analogue \{)

 2. 来自YEP_MessageCore插件的特殊消息字符
  不适用于显示具有字符\n<x>的窗口
 解决方案:使用额外的特殊字符
 \mn<x>  - 创建一个字符串为x的名称框。左侧。
 \mnc<x> - 创建一个字符串为x的名称框。中心。
 \mnr<x> - 创建一个字符串为x的名称框。右边。

 ###===========================================================================
 ## Demo
 ###===========================================================================
 https://dk-plugins.ru/mv/system/localization/

 ###===========================================================================
 ## MZ version
 ###===========================================================================
 https://dk-plugins.ru/mz/system/localization/

 ###===========================================================================
 ## 与其他插件的特殊兼容性
 ###===========================================================================
 该插件与大多数其他插件兼容，但不支持本地化的插件仍然可以包含在其中。
 我添加这些插件的兼容性。为了使兼容性正常工作，
 以下列表中的插件必须放置在本地化插件之上：
 YEP_MessageCore.js
 YEP_OptionsCore.js
 YEP_QuestJournal.js
 CGMV_Encyclopedia.js

 ## 注意！ ##
 如果你认为该插件不兼容某些插件，请告诉我。

 ###===========================================================================
 ## 使用格式
 ###===========================================================================
 可以使用下列格式进行翻译。
 1. JSON (details: https://en.wikipedia.org/wiki/JSON)
 2. CSV (details: https://en.wikipedia.org/wiki/Comma-separated_values)
 您可以在插件设置中选择格式。

 ### 注意！ ###
 翻译文件中的编码必须是不带BOM的UTF-8。
 我推荐使用Notepad++ 来编辑JSON文件。
 我推荐使用Google Docs 来编辑CSV文件。
 Microsoft Office可能不支持UTF-8！

 ###===========================================================================
 ## 用法说明
 ###===========================================================================

 ### 1 ### 开始翻译 ###
 1. 在“Game languages”参数中至少添加一种语言。
 2. 如果更改了游戏中的标准字体，则还需要在“Standard Font”参数中进行更改。
 从版本5.5.0开始，该插件具有将语言设置移动到“data/”文件夹中的JSON文件的功能。
 要执行此操作，请更改“Languages source”设置。您无需自己创建文件。
 运行游戏测试插件时将自动将所有必要的设置传输到“data/Languages.json”文件中。
 之后，您将不得不手动添加新语言，或为翻译人员提供指示。
 该文件具有以下结构：
 1. Language  - 语言名称
 2. Locale  - 区域名称
 3. Primary  - 主要语言
 4. Font  - 带有扩展名的字体文件（可选）（如果未指定，则使用标准字体）
 5. Help Text  - 选择语言时的帮助文本

 Example of JSON file:
 [
	{
		"Language": "English",
		"Locale": "en",
		"Primary": true,
		"Font": "mplus-1m-regular.ttf",
		"Help Text": "Select language"
	},
	{
		"Language": "Русский",
		"Locale": "ru",
		"Primary": false,
		"Font": null,
		"Help Text": "Выберите язык"
	}
 ]

 ## 不完整的推荐地区列表 ##
 Russian - ru
 Ukrainian - uk
 Belarusian - be
 English - en
 Chinese - zh
 Japanese - ja
 Korean - ko
 French - fe
 German - de
 Spanish - es
 Czech - cs
 Italian - it

 如果您没有在此列表中找到区域设置，您可以在互联网上找到它，例如:
 here: https://www.science.co.il/language/Locale-codes.php

 ### 2 ### Usage ###
 1. 当您首次启动游戏时，插件将为每种语言（或csv文件）创建一个用于翻译和json文件的文件夹。
 2. 使用符号 {} 翻译某些文本，比如{你好啊}，将其翻译成 Hello 或 こんにちは 。
 3. 若要在文本中使用变量，请使用标签\VAR[ID]，其中ID是变量的编号。仅用于翻译的层次（见下文）。
 
 ### 添加带有消息的新翻译的示例事件（JSON） ###
 1. 地图上创建新事件，新建文本输出消息。
 2. 在消息编辑界面中，写入{text}，然后保存到文件。
 3. 打开每种语言的json文件，例如zh.json。
 4. 文件的第一个字符必须是{，最后一个字符必须是}。这些字符不可删除，
    在这些大括号内写入游戏的翻译。（JSON标准格式，请网上搜索）
 6. 将以下文本 "text":"译文" 添加到{}之中并保存它，比如zh.json文件的内容：{"text":"译文"}
 7. 启动游戏，可以看到MV编辑器中的消息编辑{你好啊}，在游戏中输出 Hello 或 こんにちは 。。
 
 ### 添加新的翻译（CSV） ###
 1. 打开csv文件。
 2. 第一行用于区域设置。区域设置必须从第二列开始编辑！
 3. 第二行和后续行直接包含文本的翻译。
 第一列必须包含标签，在第二列和后续列中，根据区域设置的翻译标签。

 ###===========================================================================
 ## Using arrays (JSON only)
 ###===========================================================================
 数组通过文件名加载到本地化数据中。

 ### Using arrays with the "quests.json" file as an example ###
 1. The file has the following structure:
 [null, { "name": "Quest 1" }, { "name": "Quest 2" }]
 2. To display the text "Quest 1" in a message, you need to write a tag
 {quests[1].name}
 To access the array, you must first write the file name,
 in which it is stored, then it must be indicated in square brackets
 the element number and the field to be used.

 ###===========================================================================
 ## 加载译文文件
 ## 每种语言使用不同的文件(音频、图像和视频)
 ###===========================================================================
 这个功能将帮助使用不同语言的特殊文件。
 例如，如果图片上有文字，那么您可以为每种语言制作不同的图片，
 插件本身将选择所需的图片。此功能仅适用于音频、视频和图像。
 
 ## 注意！ ##
 为了使此功能在移动设备和浏览器上正常工作，您必须在DKTools插件中设置Nwjs + Stamp文件系统模式！
 
 1. 在您的图像文件夹中创建一个新文件夹
 2. 将所需的游戏区域设置用作文件夹名称
 3. 将文件移动到创建的文件夹中
 
 示例：
 需要为不同语言从“img/pictures”文件夹中使用不同的图片。
 比如主要语言（例如日语）的图片在“img/pictures”文件夹中。
 在“img/pictures”下创建一个“zh”文件夹，并将中文语言的图片移动到那里。
 对于日语语言，自动使用“img/pictures”中的主文件，
 中文使用创建的“img/pictures/zh”路径下的中文图像。
 
 ## 注意！ ##
 在将游戏发布到浏览器或移动设备之前，运行DKTools插件
 命令UpdateFileSystemStamp以更新文件系统戳
 （有关详细信息，请参阅DKTools插件帮助）。

 ###===========================================================================
 ## 使用无限数量的翻译文件
 ###===========================================================================
 ## 注意！ ##
 为了使此功能在移动设备和浏览器上正常工作，您必须在DKTools插件中设置Nwjs + Stamp文件系统模式！
 此说明适用于具有默认名称（locales）的文件夹。
 如果您在插件设置中重命名了文件夹，则请使用新的文件夹名称！
 
 如果您的游戏中有大量文本，且不方便使用一个json/csv文件，
 那么您可以将其拆分为多个json/csv文件并将其放入单独的文件夹中
 例如locales/zh/xxx.json，locales/ru/xxx.json。
 对于CSV文件，您必须将所有文件放在locales根目录中，不支持子文件夹！
 
 英语区域设置示例（en）（JSON）：
 1. 在locales文件夹中，创建一个“en”文件夹。
 2. 将旧的en.json文件从locales文件夹转移到新文件夹中。
 3. 创建几个具有任何名称的json文件。
 4. 在每个文件中写下所需的标签并保存更改。
 ## 注意！ ##
 所有文件中的所有标签必须具有唯一名称！
 如果标签名称匹配，则将加载第一个（顺序不保证）！
 
 ### 3 ### 插件参数 ###
 1. 忽略的文件 - UpdateLocalizationTags和ExportAllText插件命令忽略的文件。
 2. 解析深度 - 文本翻译操作的数量。
 在翻译文本中，您可以指定另一个标签，如果翻译深度大于1，则将翻译该标签。
 例：
 "text": "Text {text2}",
 "text2" "2"
 具有超过1的翻译深度，结果为"Text 2"。
 3. 文本长度 - 保存在缓存中的文本长度。
 这是为了减少翻译的计算资源。
 在地图之间切换时，缓存会自动清除。

 ### 4 ### 消息特殊符号 ###
 1. \language - 显示当前语言的名称
 
 ### 5 ### 插件命令 ###
 1. 提取未翻译的标签：UpdateLocalizationTags
 插件命令会检查“data/”中的json文件，除了指定在插件参数中忽略的文件，
 还会检查所有插件的所有参数。
 发现缺少于本地化文件夹的标签的标签
 将保存到命名为"new_exported_tags_"的新文件中。
 
 2. 清除本地化缓存：ClearLocalizationCache
 
 3. 导出所有文本：ExportAllText IGNORE_TAGS
 IGNORE_TAGS - 是否忽略本地化标签？true/false
 插件命令会检查“data/”中的json文件，除了指定在插件参数中忽略的文件，
 还会检查所有插件的所有参数。发现的文本会保存到本地化文件夹中的export.txt文件中。
 与UpdateLocalizationTags命令不同，此命令会保存所有文本，而不仅仅是标签。

 ### 6 ### Script calls ###
 1. DKTools.Localization.locale - Get current locale
 2. DKTools.Localization.locales - Get an array of locales
 3. DKTools.Localization.language - Get current language
 4. DKTools.Localization.languages - Get an array of languages
 5. DKTools.Localization.getText(text) - Get localized text
 6. DKTools.Localization.getPrevLocale() - Get previous locale
 7. DKTools.Localization.getNextLocale() - Get next locale
 8. DKTools.Localization.getPrevLanguage() - Get previous language
 9. DKTools.Localization.getNextLanguage() - Get next language
 10. DKTools.Localization.selectLocale(locale) - Set locale (async, returns Promise)
 11. DKTools.Localization.selectPrevLocale() - Select previous locale (async, returns Promise)
 12. DKTools.Localization.selectNextLocale() - Select next locale (async, returns Promise)
 13. DKTools.Localization.addChangeLocaleListener(function) - Add "change locale listener" (sync/async function)
 14. DKTools.Localization.getPrimaryLocale() - Get primary locale
 15. DKTools.Localization.getPrimaryLanguage() - Get primary language

 ### 7 ### How to add the option to YEP_OptionsCore.js ###
 1. 将YEP_OptionsCore插件放在上面的插件列表中
 2. 在本地化插件中启用“Show Options Command”参数
 3. 在YEP_OptionsCore.js中配置新选项，参数如下:
 Symbol: locale
 Show/Hide:
 show = LocalizationParam.get('Show Options Command');
 Draw Option Code:
 var rect = this.itemRectForText(index);
 var statusWidth = this.statusWidth();
 var titleWidth = rect.width - statusWidth;
 this.resetTextColor();
 this.changePaintOpacity(this.isCommandEnabled(index));
 this.drawOptionsName(index);
 this.drawText(this.statusText(index), titleWidth, rect.y, statusWidth, 'center');

 ### 8 ### 在移动设备和浏览器上运行 ###
 1. 请确保在DKTools插件中启用了Nwjs + Stamp文件系统模式。
 2. 在编译项目之前，必须从DKTools插件执行命令UpdateFileSystemStamp
 3. 编译所需平台的项目。
 文件系统模式的描述可以在DKTools插件帮助中找到。

 ### 9 ### Language switcher in messages ###
 The function is designed to check messages in different languages.
 To open the switcher window, use the configured key in the plugin parameters.
 Default: T
 The switcher does not work when entering numbers, selecting an item,
 and the function may not work correctly if some plugins strongly change the message system.

 ###=========================================================================
 ## See also
 ###=========================================================================
 1. Game Time (https://dk-plugins.ru/game-time/)
 Time system.

 2. Globals (https://dk-plugins.ru/globals/)
 Allows you to specify variables and switches that will be “global” to all player saves.
 Changes are saved in a separate file and applied when starting a new game or loading any save.

 3. Mouse System (https://dk-plugins.ru/mouse-system/)
 Allows you to change the mouse cursor, activate events by clicking, hovering, etc.

 4. Events Glow (https://dk-plugins.ru/events-glow/)
 Allows highlighting events on mouse hover.

 5. Pictures Glow (https://dk-plugins.ru/pictures-glow/)
 Allows highlighting pictures on mouse hover.

 ###=========================================================================
 ## Graphics
 ###=========================================================================
 Additional graphics for your project: https://dk-plugins.ru/resources/

 ###===========================================================================
 ## License and terms of use
 ###===========================================================================
 You can:
 -To use the plugin for your non-commercial projects
 -Change code of the plugin

 You cannot:
 -Delete or change any information about the plugin
 -Distribute the plugin and its modifications

 ## Commercial license ##
 Visit the page: https://dk-plugins.ru/commercial-license/

 ###===========================================================================
 ## Support
 ###===========================================================================
 Become a subscriber on boosty: https://boosty.to/dkplugins
 Become a subscriber on patreon: https://patreon.com/dkplugins



 * @param Localization
 * @default ---------------------------------

 * @param Languages Source
 * @text Languages Source
 * @parent Localization
 * @desc 添加新的译文语言到游戏中，以json格式……
 * @type select
 * @option Plugin parameters
 * @value parameters
 * @option data/Languages.json
 * @value json
 * @default parameters

 * @param Languages
 * @text Languages
 * @parent Languages Source
 * @desc 游戏语言列表。仅适用于"Languages source" = "Plugin parameters"。
 * @type struct<Language>[]
 * @default ["{\"Language\":\"日本语\",\"Locale\":\"ja\",\"Primary\":\"true\"}","{\"Language\":\"简体中文\",\"Locale\":\"zh\",\"Primary\":\"false\"}"]

 * @param Locale File
 * @text Path to save the language of the game
 * @parent Localization
 * @desc 保存游戏语言的路径
 * @default save/locale.rpgsave

 * @param Localization Folder
 * @text Path to the localization folder
 * @parent Localization
 * @desc 存放译文.json/.csv文件夹的路径
 * @default locales/

 * @param Check Subfolders
 * @text Scan Subfolders
 * @parent Localization Folder
 * @desc 扫描子目录吗？最多支持500个json文件
 * @type boolean
 * @default false

 * @param Localization Extension
 * @text Localization file format
 * @parent Localization
 * @desc 译文文件使用JSON或CSV格式
 * @type select
 * @option JSON
 * @value .json
 * @option CSV
 * @value .csv
 * @default .json

 * @param CSV delimiter
 * @text Delimiter for CSV values
 * @parent Localization Extension
 * @desc CSV的value的分隔符
 * @type combo
 * @option ;
 * @option ,
 * @default ,

 * @param Standard Font
 * @text Standard Font
 * @parent Localization
 * @desc 标准字体(带扩展)从“fonts/”文件夹加载
 * @type combo
 * @option mplus-1m-regular.ttf
 * @default mplus-1m-regular.ttf

 * @param Fonts
 * @text Fonts
 * @parent Localization
 * @desc 每种语言的字体
 * @type struct<Font>[]
 * @default []

 * @param First Launch
 * @text First Launch
 * @parent Localization
 * @desc 第一次开始游戏时显示语言选择?
 * @type boolean
 * @default false

 * @param First Launch Cursor
 * @text First Launch Cursor
 * @parent First Launch
 * @desc 第一次选择时选择的语言(游标或标志)
 * @type select
 * @option Auto (based on system language) (experimentally)
 * @value auto
 * @option Primary language from the list of languages
 * @value primary
 * @default auto

 * @param Cache
 * @text Cache
 * @parent Localization
 * @default ---------------------------------

 * @param Text Length
 * @text Text Length
 * @parent Cache
 * @desc 保存到缓存中的文本的最小长度。详情请参阅插件帮助。
 * @type number
 * @min 8
 * @default 20

 * @param Parse Depth
 * @text Parse Depth
 * @parent Localization
 * @desc 深度解析。详情请参阅插件帮助。
 * @type number
 * @min 1
 * @max 5
 * @default 2

 * @param Update Localization Tags
 * @text Update Localization Tags
 * @parent Localization
 * @default ---------------------------------

 * @param Ignored Files
 * @text Ignored Files
 * @parent Update Localization Tags
 * @desc 忽略来自"data/"的文件。详情请参阅插件帮助。
 * @type string[]
 * @default ["MapInfos","Tilesets","Stamp"]

 * @param Title Menu
 * @text Title Menu
 * @default ---------------------------------

 * @param Show Command
 * @text Show Command
 * @parent Title Menu
 * @desc 在标题菜单中显示命令?
 * @type boolean
 * @default true

 * @param Command Name
 * @text Command Name
 * @parent Title Menu
 * @desc 命令名称
 * @default {interface_language}

 * @param Button
 * @parent Title Menu
 * @text Button on the title screen
 * @default ---------------------------------

 * @param Show Button
 * @text Show Button
 * @parent Button
 * @desc 在标题菜单中显示按钮?
 * @type boolean
 * @default false

 * @param Button Graphic
 * @text Button Graphic
 * @parent Button
 * @desc 按钮图形来自img/system。使用%1替换为区域设置，例如locale_%1。
 * @default 

 * @param Button X
 * @text Button X
 * @parent Button
 * @desc 按钮中心的X坐标
 * @type number
 * @min 0
 * @default 0

 * @param Button Y
 * @text Button Y
 * @parent Button
 * @desc 按钮中心的Y坐标
 * @type number
 * @min 0
 * @default 0

 * @param Options
 * @default ---------------------------------

 * @param Show Options Command
 * @text Show Options Command
 * @parent Options
 * @desc 在选项中显示命令?
 * @type boolean
 * @default true

 * @param Options Command Name
 * @text Options Command Name
 * @parent Options
 * @desc 命令名称
 * @default {interface_language}

 * @param Rename Options Text
 * @text Rename Options Text
 * @parent Options
 * @desc 重命名选项文本(ON/OFF)?
 * @type boolean
 * @default false

 * @param Options ON Text
 * @text Options ON Text
 * @parent Rename Options Text
 * @desc Option ON text
 * @default {options_on}

 * @param Options OFF Text
 * @text Options OFF Text
 * @parent Rename Options Text
 * @desc Option OFF text
 * @default {options_off}

 * @param Scene Localization
 * @text Scene Localization
 * @text Appearance
 * @default ---------------------------------

 * @param Background Filename
 * @text Background
 * @parent Scene Localization
 * @desc 背景
 * @type file
 * @dir img/system/

 * @param Foreground Filename
 * @text Foreground
 * @parent Scene Localization
 * @desc 前景
 * @type file
 * @dir img/system/

 * @param Help Text
 * @text Help Text
 * @parent Scene Localization
 * @desc 每种语言的帮助文本
 * @type struct<HelpText>[]
 * @default ["{\"Locale\":\"ja\",\"Text\":\"日本語を選択\"}","{\"Locale\":\"zh\",\"Text\":\"选择您的语言\"}"]

 * @param BGM
 * @parent Scene Localization
 * @desc BGM
 * @type struct<BGM>
 * @default {"BGM":"","Volume":"0","Pan":"0","Pitch":"100"}

 * @param Flag Filename
 * @text Flag Filename
 * @parent Scene Localization
 * @desc img/system中的标志文件名。使用%1替换为区域设置，例如flag_%1。
 * @default 

 * @param Font Size
 * @text Font Size
 * @parent Scene Localization
 * @desc 字体大小
 * @type number
 * @min 1
 * @default 28

 * @param Style
 * @text Style
 * @parent Scene Localization
 * @desc Style
 * @type select
 * @option Window
 * @option Flags
 * @default Window

 * @param Style Window
 * @text Style Window
 * @parent Scene Localization
 * @desc 样式窗口的设置
 * @type struct<StyleWindow>
 * @default {"Window Width":"400","Window Rows":"2","Row Height":"48","Help Window":"{\"Show\":\"true\",\"Show Frame\":\"true\",\"Background Opacity\":\"192\",\"Y\":\"\\\"Graphics.boxHeight / 4;\\\"\",\"Width\":\"400\"}"}

 * @param Style Flags
 * @text Style Flags
 * @parent Scene Localization
 * @desc 样式标志的设置
 * @type struct<StyleFlags>
 * @default {"Mouse Scroll":"true","Loop Scroll":"true","Side Flags":"{\"Left Flag X\":\"\\\"Graphics.boxWidth / 3 - (Graphics.boxWidth / 3 - left.width * left.anchor.x) / 2;\\\"\",\"Right Flag X\":\"\\\"Graphics.boxWidth * 2 / 3 + (Graphics.boxWidth / 3 - right.width * right.anchor.x) / 2;\\\"\",\"Opacity\":\"128\",\"Scale\":\"0.65\"}","Flag Animation":"{\"Enabled\":\"true\",\"Duration\":\"60\",\"Min Scale\":\"0.95\",\"Max Scale\":\"1.05\"}","Help Window":"{\"Show\":\"true\",\"Show Frame\":\"true\",\"Background Opacity\":\"192\",\"Y\":\"\\\"Graphics.boxHeight / 4;\\\"\",\"Width\":\"400\"}","Language Window":"{\"Show\":\"true\",\"Show Frame\":\"true\",\"Background Opacity\":\"192\",\"Y\":\"\\\"Graphics.boxHeight * 3 / 4 - 72;\\\"\",\"Width\":\"400\"}","Play Cursor Sound":"true","Play Ok Sound":"true","Play Cancel Sound":"true"}

 * @param Map
 * @text Map
 * @default ---------------------------------

 * @param Message Switcher
 * @text Message Switcher
 * @parent Map
 * @default ---------------------------------

 * @param Message Switcher Button
 * @text Message Switcher Button
 * @parent Message Switcher
 * @desc 切换键代码. 84 - T
 * @type number
 * @default 84

 * @param Message Switcher X
 * @text Message Switcher X
 * @parent Message Switcher
 * @desc 窗口的X坐标
 * @type number
 * @default 0

 * @param Message Switcher Y
 * @text Message Switcher Y
 * @parent Message Switcher
 * @desc 窗口的Y坐标
 * @type number
 * @default 0

 * @param Message Switcher Width
 * @text Message Switcher Width
 * @parent Message Switcher
 * @desc 窗口的宽度
 * @type number
 * @default 400

*/

/*~struct~Language:

 * @param Language
 * @text 语言名称
 * @desc Language name
 * @type combo
 * @option 简体中文
 * @option English
 * @option Русский
 * @option 日本語
 * @default 简体中文

 * @param Locale
 * @text 语言缩写名称
 * @desc Short language name (locale/language code)
 * @type combo
 * @option zh
 * @option en
 * @option ru
 * @option ja
 * @default zh

 * @param Primary
 * @text 主要语言
 * @desc 这是游戏的主要语言吗？
 * @type boolean
 * @default false

*/

/*~struct~HelpText:

 * @param Locale
 * @desc Game locale
 * @type combo
 * @option zh
 * @option en
 * @option ru
 * @option ja
 * @default zh

 * @param Text
 * @desc Help text
 * @type combo
 * @option 选择您的语言
 * @option Select language
 * @option Выберите язык
 * @option 言語の選択
 * @default 选择您的语言

*/

/*~struct~Font:

 * @param Locale
 * @desc Game locale
 * @type combo
 * @option en
 * @option ru
 * @default en

 * @param Font
 * @desc Font (with file extension). For example, my_amazing_font.ttf
 * @type combo
 * @option mplus-1m-regular.ttf
 * @default mplus-1m-regular.ttf

*/

/*~struct~BGM:

 * @param BGM
 * @desc BGM filename
 * @type file
 * @dir audio/bgm

 * @param Volume
 * @desc Volume
 * @type number
 * @min 1
 * @max 100
 * @default 90

 * @param Pan
 * @desc Panorama
 * @type number
 * @min -100
 * @max 100
 * @default 0

 * @param Pitch
 * @desc Pitch
 * @type number
 * @min 50
 * @max 150
 * @default 100

*/

/*~struct~StyleWindow:

 * @param Window Width
 * @desc Window width
 * @type number
 * @min 1
 * @default 400

 * @param Window Rows
 * @text 可见行数
 * @desc Number of visible rows
 * @type number
 * @min 2
 * @default 2

 * @param Row Height
 * @desc Row height in pixels
 * @type number
 * @min 16
 * @default 48

 * @param Help Window
 * @desc Help window
 * @type struct<Window>
 * @default {"Show":"true","Show Frame":"true","Background Opacity":"192","Y":"\"Graphics.boxHeight / 4;\"","Width":"400"}

*/

/*~struct~StyleFlags:

 * @param Mouse Scroll
 * @desc Scrolling the list with the mouse wheel ?
 * @type boolean
 * @default true

 * @param Loop Scroll
 * @desc Loop scrolling of flags
 * @type boolean
 * @default true

 * @param Side Flags
 * @desc Side flags
 * @type struct<SideFlags>
 * @default {"Left Flag X":"\"Graphics.boxWidth / 3 - (Graphics.boxWidth / 3 - left.width * left.anchor.x) / 2;\"","Right Flag X":"\"Graphics.boxWidth * 2 / 3 + (Graphics.boxWidth / 3 - right.width * right.anchor.x) / 2;\"","Opacity":"128","Scale":"0.65"}

 * @param Flag Animation
 * @desc Flag animation
 * @type struct<FlagAnimation>
 * @default {"Enabled":"true","Duration":"60","Min Scale":"0.95","Max Scale":"1.05"}

 * @param Help Window
 * @desc Help window
 * @type struct<Window>
 * @default {"Show":"true","Show Frame":"true","Background Opacity":"192","Y":"\"Graphics.boxHeight / 4;\"","Width":"400"}

 * @param Language Window
 * @desc Language window
 * @type struct<Window>
 * @default {"Show":"true","Show Frame":"true","Background Opacity":"192","Y":"\"Graphics.boxHeight * 3 / 4 - 72;\"","Width":"400"}

 * @param Play Cursor Sound
 * @desc Play cursor sound
 * @type boolean
 * @default true

 * @param Play Ok Sound
 * @desc Play ok sound
 * @type boolean
 * @default true

 * @param Play Cancel Sound
 * @desc Play cancel sound
 * @type boolean
 * @default true

*/

/*~struct~FlagAnimation:

 * @param Enabled
 * @desc Enable flag animation ?
 * @type boolean
 * @default true

 * @param Duration
 * @desc Animation duration
 * @type number
 * @min 2
 * @default 60

 * @param Min Scale
 * @desc Minimum scaling of flag (X and Y)
 * @type number
 * @decimals 2
 * @min 0.05
 * @max 2.00
 * @default 0.95

 * @param Max Scale
 * @desc Maximum scaling of flag (X and Y)
 * @type number
 * @decimals 2
 * @min 0.05
 * @max 2.00
 * @default 1.05

*/

/*~struct~SideFlags:

 * @param Left Flag X
 * @desc The X coordinate of left flag. Calculated with Javascript.
 * @type note
 * @default "Graphics.boxWidth / 3 - (Graphics.boxWidth / 3 - left.width * left.anchor.x) / 2;"

 * @param Right Flag X
 * @desc The X coordinate of right flag. Calculated with Javascript.
 * @type note
 * @default "Graphics.boxWidth * 2 / 3 + (Graphics.boxWidth / 3 - right.width * right.anchor.x) / 2;"

 * @param Opacity
 * @desc Opacity
 * @type number
 * @min 1
 * @default 128

 * @param Scale
 * @desc Scaling (X and Y)
 * @type number
 * @decimals 2
 * @min 0.05
 * @max 2.00
 * @default 0.65

*/

/*~struct~Window:

 * @param Show
 * @desc Show window ?
 * @type boolean
 * @default true

 * @param Show Frame
 * @desc Show window frame ?
 * @type boolean
 * @default true

 * @param Background Opacity
 * @desc Background opacity
 * @type number
 * @min 0
 * @max 255
 * @default 192

 * @param Y
 * @desc The Y coordinate of window. Calculated with Javascript.
 * @type note
 * @default "0"

 * @param Width
 * @desc Width of window. Calculated with Javascript.
 * @type note
 * @default "400"

*/

'use strict';

var Imported = Imported || {};
Imported['DKTools_Localization'] = '5.5.7';

if (Imported['DKTools']) {
    DKTools.PluginManager.requirePlugin('DKTools', '11.2.5');
} else {
    throw new Error('No plugin "DKTools"! Plugin "DKTools_Localization" will not work!');
}

//===========================================================================
// initialize parameters
//===========================================================================

const LocalizationParam = new DKTools.ParameterManager('DKTools_Localization');

//===========================================================================
// initialize plugin commands
//===========================================================================

DKTools.PluginCommandManager.set('UpdateLocalizationTags', async () => {
    if (!Utils.isNwjs()) {
        return;
    }

    const directory = new DKTools.IO.Directory('data/');
    const result = await directory.getJsonFilesAsync();

    if (result.status !== DKTools.IO.OK) {
        DKTools.Utils.throwError(new Error('Cannot load json files from folder "data/"'));

        return;
    }

    if (result.data.length === 0) {
        DKTools.Utils.throwError(new Error('Folder "data/" does not contain json files'));

        return;
    }

    const ignoredFiles = LocalizationParam.get('Ignored Files');
    const files = _.filter(result.data,
        file => !ignoredFiles.includes(file.getName()));

    if (files.length === 0) {
        return;
    }

    const extension = DKTools.Localization._fileExtension;
    const regex = DKTools.Localization.regexTag;
    const data = {};

    const processMatch = (regex, value) => {
        let result = regex.exec(value);

        while (result !== null) {
            const match = result[1];

            if (extension === '.json') {
                _.set(data, match, '');
            } else {
                data[match] = '';
            }

            result = regex.exec(value);
        }
    };

    const parseObject = (object) => {
        if (!(object instanceof Object)) {
            return;
        }

        _.forEach(object, (value) => {
            if (DKTools.Utils.isString(value)) {
                processMatch(regex, value);
            } else {
                parseObject(value);
            }
        });
    };

    for (const file of files) {
        const fileData = await file.loadJsonAsync().then(result => result.data);

        if (!fileData) {
            continue;
        }

        if (/Map\d{3,}/.test(file.getName()) && DKTools.Utils.isString(fileData.displayName)) {
            processMatch(regex, fileData.displayName);
        }

        _.forEach(fileData, parseObject);
    }

    $plugins.forEach((plugin) => {
        parseObject(new DKTools.ParameterManager(plugin.name)._params);
    });

    if (extension === '.json') {
        const promises = DKTools.Localization.locales.map(async (locale) => {
            const basePath = DKTools.Localization._dataPath + locale;
            const file = new DKTools.IO.File(basePath + '.json');
            const localizationData = await DKTools.Localization._loadData(locale);
            let needSave = false;

            if (localizationData) {
                const newData = {};

                _.forEach(data, (value, key) => {
                    if (_.get(localizationData, key) === undefined) {
                        newData[key] = value;
                        needSave = true;
                    }
                });

                if (!needSave) {
                    return Promise.resolve();
                }

                const newFile = new DKTools.IO.File(basePath + `new_exported_tags_${locale}.json`);

                return newFile.saveJsonAsync(newData, { createDirectory: true });
            } else {
                return file.saveJsonAsync(data, { createDirectory: true });
            }
        });

        Promise.all(promises).then(() => {
            alert('Localization tags updated!');
        });
    } else {
        const basePath = DKTools.Localization._dataPath;
        const locales = DKTools.Localization.locales;
        const temp = {};
        const promises = DKTools.Localization.locales.map(async (locale) => {
            const localizationData = await DKTools.Localization._loadData(locale);

            if (localizationData) {
                const newData = {};
                let needSave = false;

                _.forEach(data, (value, key) => {
                    if (localizationData[key] === undefined) {
                        newData[key] = value;
                        needSave = true;
                    }
                });

                if (!needSave) {
                    temp[locale] = [];

                    return;
                }

                temp[locale] = Object.keys(newData)
                                      .sort((a, b) => a.length - b.length);
            } else {
                temp[locale] = Object.keys(data)
                                      .sort((a, b) => a.length - b.length);
            }
        });

        Promise.all(promises).then(() => {
            if (Object.keys(temp).length > 0) {
                const delimiter = LocalizationParam.get('CSV delimiter') || ';';
                const max = Math.max(...locales.map(locale => temp[locale].length));
                const content = [];

                for (let i = 0; i < max; i++) {
                    const row = [];

                    for (const locale of locales) {
                        row.push(temp[locale][i] || '');
                    }

                    if (row.every(value => !value)) {
                        continue;
                    }

                    content.push(row.join(delimiter));
                }

                if (content.length === 0) {
                    return;
                }

                const header = locales.join(delimiter);
                const rows = [header].concat(content).join('\n');
                const newFile = new DKTools.IO.File(basePath + 'new_exported_tags.csv');

                newFile.saveAsync(rows, { createDirectory: true }).then(() => {
                    alert('Localization tags updated!');
                });
            }
        });
    }
});

DKTools.PluginCommandManager.set('ClearLocalizationCache', () => {
    DKTools.Localization.clearCache();
});

DKTools.PluginCommandManager.set('ExportAllText', async (args) => {
    if (!Utils.isNwjs()) {
        return;
    }

    const directory = new DKTools.IO.Directory('data/');
    const result = await directory.getJsonFilesAsync();

    if (result.status !== DKTools.IO.OK) {
        DKTools.Utils.throwError(new Error('Cannot load json files from folder "data/"'));

        return;
    }

    if (result.data.length === 0) {
        DKTools.Utils.throwError(new Error('Folder "data/" does not contain json files'));

        return;
    }

    const ignoredFiles = LocalizationParam.get('Ignored Files');
    const files = _.filter(result.data,
        file => !ignoredFiles.includes(file.getName()));

    if (files.length === 0) {
        return;
    }

    const exportFile = new DKTools.IO.File(DKTools.Localization._dataPath + '/export.txt');
    const ignoreTags = eval(args[0]) || false;
    const regex = DKTools.Localization.regexTag;
    const data = {};

    const parseObject = (object) => {
        if (!(object instanceof Object)) {
            return;
        }

        _.forEach(object, (value) => {
            if (DKTools.Utils.isString(value)) {
                try {
                    parseObject(JSON.parse(value));
                } catch (e) {
                    if (!data[value] && (!ignoreTags || !value.match(regex))) {
                        data[value] = true;
                    }
                }
            } else {
                parseObject(value);
            }
        });
    };

    for (const file of files) {
        const fileData = await file.loadJsonAsync().then(result => result.data);

        if (!fileData) {
            continue;
        }

        if (/Map\d{3,}/.test(file.getName()) && DKTools.Utils.isString(fileData.displayName)) {
            if (!data[fileData.displayName]) {
                data[fileData.displayName] = true;
            }
        }

        _.forEach(fileData, parseObject);
    }

    $plugins.forEach((plugin) => {
        parseObject(new DKTools.ParameterManager(plugin.name)._params);
    });

    exportFile.saveAsync(Object.keys(data).join('\n')).then(() => {
        alert(`All text was exported! File path: ${exportFile.getFullPath()}`);
    });
});

//===========================================================================
// DKTools.Localization
//===========================================================================

/**
 * Static localization class
 * @class
 * @memberof DKTools
 */
DKTools.Localization = class {

    constructor() {
        return DKTools.Localization;
    }

    // static properties

    /**
     * @private
     * @static
     * @readonly
     * @type {String}
     */
    static get _localePath() {
        return DKTools.IO.normalizePath(LocalizationParam.get('Locale File'));
    }

    /**
     * @private
     * @static
     * @readonly
     * @type {String}
     */
    static get _dataPath() {
        return DKTools.IO.normalizePath(
            LocalizationParam.get('Localization Folder') + '/');
    }

    /**
     * @since 4.4.0
     *
     * @private
     * @static
     * @readonly
     * @type {String}
     */
    static get _webStoragePath() {
        return 'RPG Locale';
    }

    /**
     * @since 4.4.0
     * @private
     * @static
     * @readonly
     * @type {DKTools.IO.File}
     */
    static get _file() {
        return new DKTools.IO.File(this._localePath);
    }

    /**
     * @since 4.5.1
     * @private
     * @static
     * @readonly
     * @type {String}
     */
    static get _fileExtension() {
        return LocalizationParam.get('Localization Extension') || '.json';
    }

    // _initialize methods

    /**
     * @version 5.5.0
     * @private
     * @static
     * @async
     */
    static async _initializeLanguages() {
        const source = LocalizationParam.get('Languages Source') || 'parameters';
        let languages;

        if (source === 'json') {
            const file = new DKTools.IO.File('data/Languages.json');
            const fonts = LocalizationParam.get('Fonts');
            const helpText = LocalizationParam.get('Help Text');

            this._fonts = [];
            this._helpText = [];

            if (!file.exists() && Utils.isNwjs()) {
                languages = LocalizationParam.get('Languages');

                if (languages.length === 0) {
                    languages = [
                        { Locale: 'ja', Language: '日本語', Primary: true },
                        { Locale: 'zh', Language: '简体中文', Primary: false },
                        { Locale: 'en', Language: 'English', Primary: false },
                        { Locale: 'ru', Language: 'Русский', Primary: false },
                    ];
                }

                languages.forEach((data) => {
                    const font = fonts.find(f => f['Locale'] === data['Locale']);
                    const help = helpText.find(d => d['Locale'] === data['Locale']);

                    if (font && font['Font']) {
                        data['Font'] = font['Font'];
                    } else {
                        data['Font'] = null;
                    }

                    if (help && help['Text']) {
                        data['Help Text'] = help['Text'];
                    } else {
                        data['Help Text'] = null;
                    }
                });

                const result = await file.saveJsonAsync(languages);

                if (result === DKTools.IO.OK) {
                    console.log(`Created a file for languages: ${file.getFullPath()}`);
                } else {
                    console.error('Localization can not create a file for languages!');
                }
            } else {
                const result = await file.loadJsonAsync();

                if (result.status === DKTools.IO.OK) {
                    languages = result.data;
                } else {
                    DKTools.Utils.throwError(new Error(
                        `Can not load languages data from file: ${file.getFullPath()}`));
                }
            }
        } else {
            languages = LocalizationParam.get('Languages');
        }

        languages.forEach((data) => {
            this._languages[data['Locale']] = data['Language'];

            if (!this._primaryLanguage && data['Primary']) {
                this._primaryLanguage = data;
            }

            if (this._fonts && data['Font']) {
                this._fonts.push({ Font: data['Font'], Locale: data['Locale'] });
            }

            if (this._helpText && data['Help Text']) {
                this._helpText.push({ Text: data['Help Text'], Locale: data['Locale'] });
            }
        });
    }

    /**
     * @version 5.5.0
     * @private
     * @static
     * @async
     */
    static async _initializeLocale() {
        const locales = this.locales;

        if (locales.length > 0) {
            await this.loadLocale();

            if (!this._locale) {
                const firstLaunch = LocalizationParam.get('First Launch');

                if (this._primaryLanguage) {
                    this._locale = this._primaryLanguage['Locale'];
                } else {
                    this._locale = locales[0];

                    if (!firstLaunch) {
                        console.warn('You have not installed the primary language of the game! Automatically selected locale: ' + this._locale);
                    }
                }

                if (!firstLaunch) {
                    await this.saveLocale();
                }
            }
        } else {
            await this.removeLocale();

            throw new Error(
                'Add at least one language! See help of plugin "DKTools_Localization"!');
        }
    }

    /**
     * @private
     * @static
     */
    static _initializeDecrypterIgnoreList() {
        this.locales.forEach((locale) => {
            const path = `img/system/${locale}/Window.png`;
            const file = new DKTools.IO.File(path);

            if (file.exists()) {
                Decrypter._ignoreList.push(path);
            }
        });
    }

    // initialize methods

    /**
     * Initializes the manager
     * @version 4.0.0
     * @static
     * @async
     */
    static async initialize() {

        /**
         * @private
         * @readonly
         * @type {String}
         */
        this._locale = '';

        /**
         * @private
         * @readonly
         * @type {Object}
         */
        this._languages = {};

        /**
         * @private
         * @readonly
         * @type {Number}
         */
        this._parseDepth = LocalizationParam.get('Parse Depth');

        await this._initializeLanguages();
        await this._initializeLocale();
        await this._initializeDecrypterIgnoreList();

        if (Utils.isNwjs() && Utils.isTest()) {
            await this._checkData();
        }

        await this.clearCache();
        await this.loadData();
        await this.loadFont();
        await this.updateLoadingImage();

        /**
         * @private
         * @readonly
         * @type {Boolean}
         */
        this._isReady = true;
    }

    // clear methods

    /**
     * Clears the cache
     * @version 5.0.0
     * @static
     */
    static clearCache() {
        /**
         * @private
         * @readonly
         * @type {Object}
         */
        this._cache = {};

        /**
         * @private
         * @readonly
         * @type {Object}
         */
        this._cacheVariables = {};

        /**
         * @private
         * @readonly
         * @type {Object}
         */
        this._folders = {};
    }

    // _check methods

    /**
     * @version 5.5.0
     * @since 5.4.1
     * @private
     * @static
     * @async
     */
    static async _checkJsonData() {
        const dataPath = this._dataPath;
        const locales = this.locales;

        for (const locale of locales) {
            const basePath = dataPath + locale;
            const directory = new DKTools.IO.Directory(basePath);
            const file = new DKTools.IO.File(directory.getFullPath() + '/main.json');
            const oldVersionsFile = new DKTools.IO.File(basePath + '.json');

            if (oldVersionsFile.exists()) {
                continue;
            }

            if (!directory.exists()) {
                const status = await directory.createAsync();

                if (status === DKTools.IO.OK) {
                    console.log(
                        `Created a directory for locale (${locale}): ${directory.getFullPath()}`);
                } else {
                    console.error(
                        `Localization can not create a directory for locale (${locale}): ${directory.getFullPath()}`);
                }
            }

            if (!file.exists() && directory.exists()) {
                const files = await this._getLocalizationFiles(directory);

                if (files.length > 0) {
                    return;
                }

                const status = await file.saveJsonAsync({ 'attention': 'USE UTF-8 encoding!!!' });

                if (status === DKTools.IO.OK) {
                    console.log(
                        `Created a file for locale (${locale}): ${file.getFullPath()}`);
                } else {
                    console.error(
                        `Localization can not create a file for locale (${locale}): ${file.getFullPath()}`);
                }
            }
        }
    }

    /**
     * @version 5.5.0
     * @since 5.4.1
     * @private
     * @static
     * @async
     */
    static async _checkCsvData() {
        const locales = this.locales;
        const directory = new DKTools.IO.Directory(this._dataPath);
        const files = await this._getLocalizationFiles(directory);

        if (files.length > 0) {
            return;
        }

        const file = new DKTools.IO.File(directory.getFullPath() + '/main.csv');
        const delimiter = LocalizationParam.get('CSV delimiter') || ';';
        const status = await file.saveAsync(`tag;${locales.join(delimiter)}\nUSE UTF-8 encoding!!!`);

        if (status === DKTools.IO.OK) {
            console.log(`Created a file for localization: ${file.getFullPath()}`);
        } else {
            console.error(
                `Localization can not create a file for localization: ${file.getFullPath()}`);
        }
    }

    /**
     * Checks a directory and files with translations
     * Creates a directory and files if they are missing
     *
     * @version 4.5.1
     * @private
     * @static
     * @async
     */
    static async _checkData() {
        const dataPath = this._dataPath;
        const directory = new DKTools.IO.Directory(dataPath);

        if (!directory.exists()) {
            const status = await directory.createAsync();

            if (status === DKTools.IO.OK) {
                console.log(
                    'Created a directory for localization: ' + dataPath);
            } else {
                console.error(
                    'Localization can not create a directory for localization: ' + dataPath);
            }
        }

        if (this._fileExtension === '.json') {
            await this._checkJsonData();
        } else {
            await this._checkCsvData();
        }
    }

    // check methods

    /**
     * Returns true if locale is valid
     * @static
     * @param {String} locale - Locale
     * @return {Boolean} Locale is valid
     */
    static checkLocale(locale) {
        return this.locales.includes(locale);
    }

    /**
     * Checks the cache
     * @version 5.0.0
     * @static
     * @param {Number} variableId - Variable ID
     */
    static checkCache(variableId) {
        if (!this._cacheVariables[variableId]) {
            return;
        }

        this._cache = Object.keys(this._cache).reduce((acc, key) => {
            const cache = this._cache[key];

            if (cache.variables && !cache.variables.includes(variableId)) {
                acc[key] = cache;
            }

            return acc;
        }, {});
    }

    // get methods

    /**
     * Returns localization files
     * @since 5.5.0
     * @private
     * @static
     * @param {DKTools.IO.Directory} directory - Directory
     * @param {String} [extension=this._fileExtension] - File extension
     * @return {Promise<DKTools.IO.File[]>} files
     */
    static _getLocalizationFiles(directory, extension = this._fileExtension) {
        const template = new RegExp(`(${extension})`);
        let promise;

        if (LocalizationParam.get('Check Subfolders')) {
            promise = directory.findFilesAsync({ searchLimit: 500, template });
        } else {
            promise = directory.getFilesAsync({ template });
        }

        return promise.then(
            result => result.data.filter(file => !file.getName().startsWith('new_exported_tags')));
    }

    /**
     * @version 5.5.4
     * @private
     * @static
     * @return {String}
     */
    static _getText(text) {
        const cacheVariables = this._cacheVariables;
        const parseDepth = this._parseDepth;
        const regexVar = this.regexVar;
        const regex = this.regexTag;
        const data = this._data;
        const initialText = text;
        const variables = [];
        const varReplace = (text) => {
            return text.replace(regexVar, (string, match) => {
                const id = Number(match);

                cacheVariables[id] = true;

                variables.push(id);
                needCache = true;

                return $gameVariables.value(id);
            });
        };
        const textReplace = (text, regex) => {
            return text.replace(regex, (string, match) => {
                if (data.hasOwnProperty(match)) {
                    needCache = true;

                    return data[match];
                } else {
                    const value = _.get(data, match);

                    if (DKTools.Utils.isString(value)) {
                        needCache = true;

                        return value;
                    }
                }

                return match;
            });
        };
        const parseText = (text) => {
            text = varReplace(text);
            text = textReplace(text, regex);
            text = varReplace(text);

            return text;
        };

        let needCache = false;

        for (let i = 0; i < parseDepth; i++) {
            const temp = text;

            text = parseText(text);

            if (!needCache && text === temp) {
                break;
            }
        }

        if (needCache && initialText.length >= LocalizationParam.get('Text Length')) {
            this._cache[initialText] = { variables, text };
        }

        return text;
    }

    /**
     * Returns localized text
     * @version 5.5.2
     * @static
     * @param {String} text - Text
     * @return {String} Localized text
     */
    static getText(text) {
        if (text == null) {
            return text;
        }

        text = String(text);

        if (text.length < 3 || !this._data) {
            return text;
        }

        if (this._cache[text]) {
            return this._cache[text].text;
        }

        return this._getText(text);
    }

    /**
     * Returns help text
     * @since 5.5.0
     * @static
     * @param {String} locale - Locale
     * @return {String | null}
     */
    static getHelpText(locale) {
        return (this._helpText || LocalizationParam.get('Help Text'))
            .filter(data => data['Locale'] === locale)
            .map(data => data['Text'])[0] || null;
    }

    /**
     * Returns the previous locale from the list
     * @static
     * @return {String | null} Previous locale from the list
     */
    static getPrevLocale() {
        const locales = this.locales;
        let index = locales.indexOf(this._locale);

        if (index >= 0) {
            index--;

            if (index < 0) {
                index = locales.length - 1;
            }

            return locales[index];
        }

        return null;
    }

    /**
     * Returns the next locale from the list
     * @static
     * @return {String | null} Next locale from the list or null
     */
    static getNextLocale() {
        const locales = this.locales;
        let index = locales.indexOf(this._locale);

        if (index >= 0) {
            index++;

            if (index === locales.length) {
                index = 0;
            }

            return locales[index];
        }

        return null;
    }

    /**
     * Returns the previous language from the list
     * @static
     * @return {String | null} Previous language from the list or null
     */
    static getPrevLanguage() {
        const locale = this.getPrevLocale();

        if (locale) {
            return this._languages[locale];
        }

        return null;
    }

    /**
     * Returns the next language from the list
     * @static
     * @return {String | null} Next language from the list or null
     */
    static getNextLanguage() {
        const locale = this.getNextLocale();

        if (locale) {
            return this._languages[locale];
        }

        return null;
    }

    /**
     * Returns the language of the game by the locale of the game
     * @static
     * @param {String} locale - Locale
     * @return {String | undefined} Language or undefined
     */
    static getLanguageByLocale(locale) {
        return this._languages[locale];
    }

    /**
     * Returns the locale of the game by the name of the language
     * @static
     * @param {String} language - Language
     * @return {String | undefined} Locale or undefined
     */
    static getLocaleByLanguage(language) {
        const languages = _.reduce(this._languages, (acc, value, key) => {
            acc[value] = key;

            return acc;
        }, {});

        return languages[language];
    }

    /**
     * Returns the primary locale
     * @since 5.0.0
     * @static
     * @return {String | null} Primary locale
     */
    static getPrimaryLocale() {
        return LocalizationParam.get('Languages', { Primary: true }, { key: 'Locale' })
            || null;
    }

    /**
     * Returns the primary language
     * @since 5.0.0
     * @static
     * @return {String | null} Primary language
     */
    static getPrimaryLanguage() {
        return LocalizationParam.get('Languages', { Primary: true }, { key: 'Language' })
            || null;
    }

    /**
     * Returns the folder for an audio by locale
     * @version 5.5.7
     * @since 5.0.0
     * @static
     * @param {String} folder - Folder
     * @param {String} filename - Filename
     * @param {String} [locale=this.locale] - Locale
     * @return {String} Folder for an audio by locale
     */
    static getAudioFolder(folder, filename, locale = this.locale) {
        if (!folder || !filename || !DKTools.IO.isReady() || !Utils.isNwjs() && DKTools.IO.mode === DKTools.IO.MODE_NWJS) {
            return folder;
        }

        const basePath = AudioManager._path;
        const normalizedFolder = DKTools.IO.reverseSlashes(
            DKTools.IO.normalizePath(folder + '/'));
        const key = DKTools.IO.reverseSlashes(
            DKTools.IO.normalizePath(normalizedFolder + filename));
        const currentLocale = this.locale;

        if (this._folders[key] && locale === currentLocale) {
            return this._folders[key];
        }

        const newFolder = DKTools.IO.normalizePath(normalizedFolder + locale + '/');
        const newFileName = filename + AudioManager.audioFileExt();
        let newPath = DKTools.IO.normalizePath(basePath + '/' + newFolder + '/' + newFileName);

        if (new DKTools.IO.File(newPath).exists()) {
            if (locale === currentLocale) {
                this._folders[key] = newFolder;
            }

            return newFolder;
        }

        if (Decrypter.hasEncryptedAudio || !$dataSystem) {
            newPath = DKTools.IO.normalizePath(basePath + '/' + newFolder + '/' + Decrypter.extToEncryptExt(newFileName));

            if (new DKTools.IO.File(newPath).exists()) {
                if (locale === currentLocale) {
                    this._folders[key] = newFolder;
                }

                return newFolder;
            }
        }

        if (locale === currentLocale) {
            this._folders[key] = folder;
        }

        return folder;
    }

    /**
     * Returns the folder for an image by locale
     * @version 5.5.7
     * @since 5.0.0
     * @static
     * @param {String} folder - Folder
     * @param {String} filename - Filename
     * @param {String} [locale=this.locale] - Locale
     * @return {String} Folder for an image by locale
     */
    static getImageFolder(folder, filename, locale = this.locale) {
        if (!folder || !filename || !DKTools.IO.isReady() || !Utils.isNwjs() && DKTools.IO.mode === DKTools.IO.MODE_NWJS) {
            return folder;
        }

        const key = DKTools.IO.reverseSlashes(
            DKTools.IO.normalizePath(folder + '/' + filename));
        const currentLocale = this.locale;

        if (this._folders[key] && locale === currentLocale) {
            return this._folders[key];
        }

        const newFolder = DKTools.IO.normalizePath(folder + '/' + locale + '/');
        const newFileName = filename + ImageManager.imageFileExt();
        let newPath = DKTools.IO.normalizePath(newFolder + '/' + newFileName);

        if (new DKTools.IO.File(newPath).exists()) {
            if (locale === currentLocale) {
                this._folders[key] = newFolder;
            }

            return newFolder;
        }

        if (Decrypter.hasEncryptedImages || !$dataSystem) {
            newPath = DKTools.IO.normalizePath(newFolder + '/' + Decrypter.extToEncryptExt(newFileName));

            if (new DKTools.IO.File(newPath).exists()) {
                if (locale === currentLocale) {
                    this._folders[key] = newFolder;
                }

                return newFolder;
            }
        }

        if (!folder.endsWith('/')) {
            folder += '/';
        }

        if (locale === currentLocale) {
            this._folders[key] = folder;
        }

        return folder;
    }

    /**
     * Returns the folder for a video by locale
     * @version 5.5.6
     * @since 5.1.1
     * @static
     * @param {String} folder - Folder
     * @param {String} filename - Filename (with extension)
     * @param {String} [locale=this.locale] - Locale
     * @return {String} Folder for a video by locale
     */
    static getVideoFolder(folder, filename, locale = this.locale) {
        if (!folder || !filename || !DKTools.IO.isReady() || !Utils.isNwjs() && DKTools.IO.mode === DKTools.IO.MODE_NWJS) {
            return folder;
        }

        const key = DKTools.IO.reverseSlashes(
            DKTools.IO.normalizePath(folder + '/' + filename));
        const currentLocale = this.locale;

        if (this._folders[key] && locale === currentLocale) {
            return this._folders[key];
        }

        const newFolder = DKTools.IO.normalizePath(folder + '/' + locale + '/');
        const newPath = DKTools.IO.normalizePath(newFolder + '/' + filename);
        const file = new DKTools.IO.File(newPath);

        if (file.exists()) {
            if (locale === currentLocale) {
                this._folders[key] = newFolder;
            }

            return newFolder;
        }

        if (locale === currentLocale) {
            this._folders[key] = folder;
        }

        return folder;
    }

    // is methods

    /**
     * Returns true if the manager is ready
     * @since 4.0.0
     * @static
     * @return {Boolean} Manager is ready
     */
    static isReady() {
        return this._isReady;
    }

    /**
     * Returns true if the locale file exists
     * @version 5.1.3
     * @since 4.4.0
     * @static
     * @return {Boolean} Locale file exists
     */
    static isLocaleFileExists() {
        if (Utils.isNwjs()) {
            return this._file.exists();
        }

        return DKTools.IO.WebStorage.exists(this._webStoragePath);
    }

    // load methods

    /**
     * Loads the data
     * @version 5.5.4
     * @private
     * @static
     * @async
     * @param {String} locale - Locale
     * @return {Object} Data
     */
    static async _loadData(locale) {
        const extension = this._fileExtension;
        const directoryPath = extension === '.json' ?
            this._dataPath + locale : this._dataPath;
        const directory = new DKTools.IO.Directory(directoryPath);
        const delimiter = LocalizationParam.get('CSV delimiter') || ';';
        const data = {};

        const processJsonFile = async (file) => {
            const result = await file.loadJsonAsync();

            if (result.status === DKTools.IO.OK) {
                if (Array.isArray(result.data)) {
                    data[file.getName()] = result.data;

                    return;
                }

                _.forEach(result.data, (value, key) => {
                    if (data[key] === undefined) {
                        data[key] = value;
                    }
                });
            } else {
                const fullPath = file.getFullPath();

                if (result.status === DKTools.IO.ERROR_PARSING_DATA) {
                    let message = `Can not parse JSON data from file: ${fullPath}.`;

                    if (result.error && result.error.message) {
                        message += ' Description: ' + result.error.message;
                    }

                    DKTools.Utils.throwError(new Error(message));
                } else {
                    DKTools.Utils.throwError(
                        new Error(`Can not load localization data from file: ${fullPath}`));
                }
            }

            return Promise.resolve();
        };

        // TODO: optimize
        const processCsvFile = async (file) => {
            const result = await file.loadAsync();

            if (result.status === DKTools.IO.OK) {
                const rows = result.data.split('\n');

                if (rows.length === 0) {
                    DKTools.Utils.throwError(new Error(
                        `Localization CSV file is empty: ${file.getFullPath()}`));
                }

                const header = rows[0].split(delimiter);

                if (header.length <= 1) {
                    DKTools.Utils.throwError(new Error(
                        `Localization file "${file.getFullPath()}" failed to parse first row by delimiter "${delimiter}" for locale "${locale}"`));
                    return Promise.reject();
                }

                const localeIndex = header.findIndex(key =>
                    key.trim().toLowerCase() === locale.toLowerCase());

                if (localeIndex === -1) {
                    DKTools.Utils.throwError(new Error(
                        `Localization file "${file.getFullPath()}" does not include translation for locale "${locale}"`));
                    return Promise.reject();
                } else {
                    rows.slice(1).forEach((row, index) => {
                        if (!row) {
                            return;
                        }

                        const values = row.split(delimiter);

                        if (values.length <= 1) {
                            console.error(
                                `Localization file "${file.getFullPath()}" failed to parse row ${index + 1} by delimiter "${delimiter}". Skipped...`);
                            return;
                        }

                        const key = values[0];

                        if (data[key] === undefined) {
                            data[key] = values[localeIndex].trim().replace(/\\n/g, '\n');
                        }
                    });
                }
            }

            return Promise.resolve();
        };

        if (directory.exists()) {
            const files = await this._getLocalizationFiles(directory, extension);

            if (files.length > 0) {
                if (extension === '.json') {
                    await Promise.all(files.map(processJsonFile));
                } else {
                    await Promise.all(files.map(processCsvFile));
                }
            } else {
                DKTools.Utils.throwError(
                    new Error(`Localization directory is empty: ${directoryPath}`));
            }
        } else if (extension === '.json') {
            const filePath = directoryPath + extension;
            const file = new DKTools.IO.File(filePath);

            if (file.exists()) {
                await processJsonFile(file);
            } else {
                DKTools.Utils.throwError(
                    new Error(`Localization file does not exist: ${filePath}`));
            }
        }

        return data;
    }

    /**
     * Loads the locale
     * @version 4.2.0
     * @static
     * @async
     */
    static async loadLocale() {
        let locale;

        if (Utils.isNwjs()) {
            locale = await this._file.loadAsync().then(result => result.data);
        } else {
            locale = DKTools.IO.WebStorage.load(this._webStoragePath).data;
        }

        if (this.checkLocale(locale)) {
            this._locale = locale;
        } else if (!LocalizationParam.get('First Launch')) {
            await this.removeLocale();
        }
    }

    /**
     * Loads the data
     * @version 4.0.0
     * @static
     * @async
     */
    static async loadData() {
        this._data = await this._loadData(this._locale);
    }

    /**
     * Loads the font
     * @version 5.5.0
     * @static
     * @async
     */
    static async loadFont() {
        return new Promise((resolve) => {
            const font = (this._fonts || LocalizationParam.get('Fonts'))
                .find(f => f['Locale'] === this.locale);
            const fontPath = (font ?
                font['Font'] : LocalizationParam.get('Standard Font'));

            Graphics.loadFont('GameFont', 'fonts/' + fontPath);

            if (Graphics.isFontLoaded('GameFont')) {
                resolve();
            } else {
                const interval = setInterval(() => {
                    if (Graphics.isFontLoaded('GameFont')) {
                        clearInterval(interval);

                        resolve();
                    }
                }, 50);
            }
        });
    }

    // other methods

    /**
     * Saves the locale
     * @version 4.0.0
     * @static
     * @async
     */
    static async saveLocale() {
        if (Utils.isNwjs()) {
            await this._file.saveAsync(this._locale, { createDirectory: true });
        } else {
            DKTools.IO.WebStorage.save(this._webStoragePath, this._locale);
        }
    }

    /**
     * Removes the locale
     * @static
     * @async
     */
    static async removeLocale() {
        if (Utils.isNwjs()) {
            await this._file.removeAsync();
        } else {
            DKTools.IO.WebStorage.remove(this._webStoragePath);
        }
    }

    /**
     * Selects the previous locale from the list
     * @static
     * @async
     * @return {Promise}
     */
    static async selectPrevLocale() {
        return this.selectLocale(this.getPrevLocale());
    }

    /**
     * Selects the next locale from the list
     * @static
     * @async
     * @return {Promise}
     */
    static async selectNextLocale() {
        return this.selectLocale(this.getNextLocale());
    }

    /**
     * Selects the locale
     * @since 5.0.0
     * @static
     * @async
     * @param {String} locale - Locale
     * @return {Promise}
     */
    static async selectLocale(locale) {
        if (this.checkLocale(locale)) {
            const previousLocale = this._locale;

            this._locale = locale;

            if (this._locale !== previousLocale || !this.isLocaleFileExists()) {
                await this.saveLocale();
            }

            if (this._locale !== previousLocale) {
                await this._onLocaleChange(previousLocale);
            }
        } else {
            return Promise.reject('You are trying to establish a non-existent locale: ' + locale);
        }
    }

    /**
     * Handles the change of the game locale
     * @version 5.0.0
     * @private
     * @static
     * @async
     * @param {String} previousLocale - Previous locale
     */
    static async _onLocaleChange(previousLocale) {
        await this.clearCache();
        await this.loadData();
        await this.loadFont();
        await this.updateLoadingImage();
        await this.updateGameTitle();

        for (const listener of this._listeners) {
            await listener(previousLocale, this._locale);
        }
    }

    /**
     * Adds a listener of change of the game locale
     * @static
     * @param {Function} listener - Listener (sync/async function)
     * @example
     * DKTools.Localization.addChangeLocaleListener((previousLocale, locale) => {
     *      // your code
     * });
     */
    static addChangeLocaleListener(listener) {
        if (DKTools.Utils.isFunction(listener)) {
            this._listeners.push(listener);
        }
    }

    // update methods

    /**
     * Updates the game title
     * @since 4.5.0
     * @static
     */
    static updateGameTitle() {
        document.title = this.getText($dataSystem.gameTitle);
    }

    /**
     * Updates the image of loading
     * @version 4.3.0
     * @static
     */
    static updateLoadingImage() {
        if (!Utils.isNwjs() && DKTools.IO.mode === DKTools.IO.MODE_NWJS) {
            return;
        }

        const filename = 'Loading.png';
        const basePath = DKTools.IO.normalizePath('img/system/' + this._locale);
        const fullPath = DKTools.IO.normalizePath(basePath + '/' + filename);

        if (DKTools.IO.pathExists(fullPath)) {
            Graphics.setLoadingImage(fullPath);
        } else if (Decrypter.hasEncryptedImages || !$gameSystem) {
            if (DKTools.IO.pathExists(basePath + '/' + Decrypter.extToEncryptExt(filename))) {
                Graphics.setLoadingImage(fullPath);
            }
        }
    }

};

// properties

Object.defineProperties(DKTools.Localization, {

    /**
     * @private
     * @type {Object}
     * @memberof DKTools.Localization
     */
    _folders: { value: {}, writable: true },

    /**
     * @private
     * @type {Function[]}
     * @memberof DKTools.Localization
     */
    _listeners: { value: [] },

    /**
     * @private
     * @readonly
     * @type {RegExp}
     * @memberof DKTools.Localization
     */
    regexVar: { value: /\\VAR\[(\d+)\]/g },

    /**
     * @since 5.0.0
     * @private
     * @readonly
     * @type {RegExp}
     * @memberof DKTools.Localization
     */
    regexTag: { value: /\{(.*?)\}/g },

    /**
     * Locale of the game
     * @readonly
     * @type {String}
     * @memberof DKTools.Localization
     */
    locale: {
        get: function() {
            return this._locale;
        },
        configurable: true
    },

    /**
     * Language of the game
     * @readonly
     * @type {String}
     * @memberof DKTools.Localization
     */
    language: {
        get: function() {
            return this._languages[this._locale];
        },
        configurable: true
    },

    /**
     * Languages of the game
     * @readonly
     * @type {String[]}
     * @memberof DKTools.Localization
     */
    languages: {
        get: function() {
            return Object.values(this._languages);
        },
        configurable: true
    },

    /**
     * Locales of the game
     * @readonly
     * @type {String[]}
     * @memberof DKTools.Localization
     */
    locales: {
        get: function() {
            return Object.keys(this._languages);
        },
        configurable: true
    }

});

//===========================================================================
// DKTools.StartupManager
//===========================================================================

const Localization_DKTools_StartupManager_initializeModules =
    DKTools.StartupManager.initializeModules;
DKTools.StartupManager.initializeModules = async function() {
    await Localization_DKTools_StartupManager_initializeModules.apply(this, arguments);
    await DKTools.Localization.initialize();
};

//===========================================================================
// DKTools.PreloadManager
//===========================================================================

const Localization_DKTools_PreloadManager_processAudioFile =
    DKTools.PreloadManager._processAudioFile;
DKTools.PreloadManager._processAudioFile = function(file, object) {
    const name = file.getName();
    const path = DKTools.Localization.getAudioFolder(file.getDirectoryName(), name)
        + name + file.getExtension();

    Localization_DKTools_PreloadManager_processAudioFile.call(this,
        new DKTools.IO.File(AudioManager._path + path), object);
};

const Localization_DKTools_PreloadManager_processImageFile =
    DKTools.PreloadManager._processImageFile;
DKTools.PreloadManager._processImageFile = function(file, object) {
    const name = file.getName();
    const path = DKTools.Localization.getImageFolder(file.getPath(), name)
        + name + file.getExtension();

    Localization_DKTools_PreloadManager_processImageFile.call(this,
        new DKTools.IO.File(path), object);
};

//===========================================================================
// DKTools.Base
//===========================================================================

const Localization_DKTools_Base_textWrap = DKTools.Base.prototype.textWrap;
DKTools.Base.prototype.textWrap = function(text, options = {}) {
    return Localization_DKTools_Base_textWrap.call(
        this, DKTools.Localization.getText(text), options);
};

const Localization_DKTools_Base_drawTextEx = DKTools.Base.prototype.drawTextEx;
DKTools.Base.prototype.drawTextEx = function(text, options) {
    return Localization_DKTools_Base_drawTextEx.call(
        this, DKTools.Localization.getText(text), options);
};

const Localization_DKTools_Base_convertEscapeCharacters =
    DKTools.Base.prototype.convertEscapeCharacters;
DKTools.Base.prototype.convertEscapeCharacters = function() {
    return DKTools.Localization.getText(
        Localization_DKTools_Base_convertEscapeCharacters.apply(this, arguments))
            .replace(/\x1blanguage/gi, () => DKTools.Localization.language);
};

//===========================================================================
// DKTools.Sprite
//===========================================================================

const Localization_DKTools_Sprite_textWrap = DKTools.Sprite.prototype.textWrap;
DKTools.Sprite.prototype.textWrap = function(text, options = {}) {
    return Localization_DKTools_Sprite_textWrap.call(
        this, DKTools.Localization.getText(text), options);
};

const Localization_DKTools_Sprite_drawTextEx = DKTools.Sprite.prototype.drawTextEx;
DKTools.Sprite.prototype.drawTextEx = function(text, options) {
    return Localization_DKTools_Sprite_drawTextEx.call(
        this, DKTools.Localization.getText(text), options);
};

const Localization_DKTools_Sprite_convertEscapeCharacters =
    DKTools.Sprite.prototype.convertEscapeCharacters;
DKTools.Sprite.prototype.convertEscapeCharacters = function() {
    return DKTools.Localization.getText(
        Localization_DKTools_Sprite_convertEscapeCharacters.apply(this, arguments))
            .replace(/\x1blanguage/gi, () => DKTools.Localization.language);
};

const Localization_DKTools_Sprite_processEscapeCharacter =
    DKTools.Sprite.prototype.processEscapeCharacter;
DKTools.Sprite.prototype.processEscapeCharacter = function(code, textState) {
    if (code === 'MFS') {
        this.makeFontSmaller();
    } else if (code === 'MFB') {
        this.makeFontBigger();
    } else {
        Localization_DKTools_Sprite_processEscapeCharacter.apply(this, arguments);
    }
};

//===========================================================================
// DKTools.Window
//===========================================================================

const Localization_DKTools_Window_textWrap = DKTools.Window.prototype.textWrap;
DKTools.Window.prototype.textWrap = function(text, options = {}) {
    return Localization_DKTools_Window_textWrap.call(
        this, DKTools.Localization.getText(text), options);
};

//===========================================================================
// Bitmap
//===========================================================================

const Localization_Bitmap_drawText = Bitmap.prototype.drawText;
Bitmap.prototype.drawText = function(text, x, y, maxWidth, lineHeight, align) {
    Localization_Bitmap_drawText.call(
        this, DKTools.Localization.getText(text), x, y, maxWidth, lineHeight, align);
};

//===========================================================================
// Graphics
//===========================================================================

const Localization_Graphics_playVideo = Graphics.playVideo;
Graphics.playVideo = function(src) {
    const parts = src.split('/');
    const filename = parts.pop();
    const folder = DKTools.Localization.getVideoFolder(parts.join('/'), filename);

    Localization_Graphics_playVideo.call(this, folder + '/' + filename);
};

//===========================================================================
// ImageManager
//===========================================================================

const Localization_ImageManager_loadBitmap = ImageManager.loadBitmap;
ImageManager.loadBitmap = function(folder, filename, hue, smooth) {
    return Localization_ImageManager_loadBitmap.call(
        this,
        DKTools.Localization.getImageFolder(folder, filename),
        filename,
        hue,
        smooth);
};

const Localization_ImageManager_reserveBitmap = ImageManager.reserveBitmap;
ImageManager.reserveBitmap = function(folder, filename, hue, smooth, reservationId) {
    return Localization_ImageManager_reserveBitmap.call(
        this,
        DKTools.Localization.getImageFolder(folder, filename),
        filename,
        hue,
        smooth,
        reservationId);
};

const Localization_ImageManager_requestBitmap = ImageManager.requestBitmap;
ImageManager.requestBitmap = function(folder, filename, hue, smooth) {
    return Localization_ImageManager_requestBitmap.call(
        this,
        DKTools.Localization.getImageFolder(folder, filename),
        filename,
        hue,
        smooth);
};

//===========================================================================
// AudioManager
//===========================================================================

const Localization_AudioManager_createBuffer = AudioManager.createBuffer;
AudioManager.createBuffer = function(folder, name, reservationId) {
    return Localization_AudioManager_createBuffer.call(
        this,
        DKTools.Localization.getAudioFolder(folder, name),
        name,
        reservationId);
};

//===========================================================================
// TextManager
//===========================================================================

const Localization_TextManager_basic = TextManager.basic;
TextManager.basic = function(basicId) {
    return DKTools.Localization.getText(
        Localization_TextManager_basic.apply(this, arguments));
};

const Localization_TextManager_param = TextManager.param;
TextManager.param = function(paramId) {
    return DKTools.Localization.getText(
        Localization_TextManager_param.apply(this, arguments));
};

const Localization_TextManager_command = TextManager.command;
TextManager.command = function(commandId) {
    return DKTools.Localization.getText(
        Localization_TextManager_command.apply(this, arguments));
};

const Localization_TextManager_message = TextManager.message;
TextManager.message = function(messageId) {
    return DKTools.Localization.getText(
        Localization_TextManager_message.apply(this, arguments));
};

// properties

Object.defineProperty(TextManager, 'currencyUnit', {
    get: function() {
        return DKTools.Localization.getText($dataSystem.currencyUnit);
    },
    configurable: true
});

//===========================================================================
// Game_System
//===========================================================================

const Localization_Game_System_isJapanese = Game_System.prototype.isJapanese;
Game_System.prototype.isJapanese = function() {
    return Boolean(Localization_Game_System_isJapanese.apply(this, arguments)
        || DKTools.Localization.locale.match(/^ja/));
};

const Localization_Game_System_isChinese = Game_System.prototype.isChinese;
Game_System.prototype.isChinese = function() {
    return Boolean(Localization_Game_System_isChinese.apply(this, arguments)
        || DKTools.Localization.locale.match(/^zh/));
};

const Localization_Game_System_isKorean = Game_System.prototype.isKorean;
Game_System.prototype.isKorean = function() {
    return Boolean(Localization_Game_System_isKorean.apply(this, arguments)
        || DKTools.Localization.locale.match(/^ko/));
};

const Localization_Game_System_isCJK = Game_System.prototype.isCJK;
Game_System.prototype.isCJK = function() {
    return Boolean(Localization_Game_System_isCJK.apply(this, arguments)
        || DKTools.Localization.locale.match(/^(ja|zh|ko)/));
};

Game_System.prototype.isRussian = function() {
    return Boolean(DKTools.Localization.locale.match(/^ru/));
};

//===========================================================================
// Game_Message
//===========================================================================

const Localization_Game_Message_clear = Game_Message.prototype.clear;
Game_Message.prototype.clear = function() {
    Localization_Game_Message_clear.apply(this, arguments);
    this._originalTexts = [];
    this._originalChoices = [];
};

const Localization_Game_Message_add = Game_Message.prototype.add;
Game_Message.prototype.add = function(text) {
    this._originalTexts.push(text);
    Localization_Game_Message_add.call(
        this, DKTools.Localization.getText(text));
};

const Localization_Game_Message_setChoices = Game_Message.prototype.setChoices;
Game_Message.prototype.setChoices = function(choices, defaultType, cancelType) {
    this._originalChoices = choices.slice();
    choices = choices.map(choice => DKTools.Localization.getText(choice));
    Localization_Game_Message_setChoices.call(this, choices, defaultType, cancelType);
};

Game_Message.prototype.allOriginalText = function() {
    return this._originalTexts.join('\n');
};

Game_Message.prototype.getOriginalTexts = function() {
    return this._originalTexts.slice();
};

Game_Message.prototype.getOriginalChoices = function() {
    return this._originalChoices.slice();
};

//===========================================================================
// Game_Variables
//===========================================================================

const Localization_Game_Variables_setValue = Game_Variables.prototype.setValue;
Game_Variables.prototype.setValue = function(id, value) {
    const lastValue = this.value(id);

    Localization_Game_Variables_setValue.apply(this, arguments);

    if (lastValue !== this.value(id)) {
        DKTools.Localization.checkCache(id);
    }
};

//===========================================================================
// Game_Map
//===========================================================================

const Localization_Game_Map_setup = Game_Map.prototype.setup;
Game_Map.prototype.setup = function(mapId) {
    Localization_Game_Map_setup.apply(this, arguments);
    DKTools.Localization.clearCache();
};

//===========================================================================
// Window_Base
//===========================================================================

const Localization_Window_Base_textWidth =
    Window_Base.prototype.textWidth;
Window_Base.prototype.textWidth = function(text) {
    return Localization_Window_Base_textWidth.call(
        this, DKTools.Localization.getText(text));
};

const Localization_Window_Base_drawTextEx =
    Window_Base.prototype.drawTextEx;
Window_Base.prototype.drawTextEx = function(text, x, y) {
    return Localization_Window_Base_drawTextEx.call(
        this, DKTools.Localization.getText(text), x, y);
};

const Localization_Window_Base_actorName =
    Window_Base.prototype.actorName;
Window_Base.prototype.actorName = function(n) {
    return DKTools.Localization.getText(
        Localization_Window_Base_actorName.apply(this, arguments));
};

const Localization_Window_Base_partyMemberName =
    Window_Base.prototype.partyMemberName;
Window_Base.prototype.partyMemberName = function(n) {
    return DKTools.Localization.getText(
        Localization_Window_Base_partyMemberName.apply(this, arguments));
};

const Localization_Window_Base_convertEscapeCharacters =
    Window_Base.prototype.convertEscapeCharacters;
Window_Base.prototype.convertEscapeCharacters = function(text) {
    return DKTools.Localization.getText(
        Localization_Window_Base_convertEscapeCharacters.apply(this, arguments))
            .replace(/\x1blanguage/gi, () => DKTools.Localization.language);
};

const Localization_Window_Base_processEscapeCharacter =
    Window_Base.prototype.processEscapeCharacter;
Window_Base.prototype.processEscapeCharacter = function(code, textState) {
    if (code === 'MFS') {
        this.makeFontSmaller();
    } else if (code === 'MFB') {
        this.makeFontBigger();
    } else {
        Localization_Window_Base_processEscapeCharacter.apply(this, arguments);
    }
};

//===========================================================================
// Window_Command
//===========================================================================

const Localization_Window_Command_commandName =
    Window_Command.prototype.commandName;
Window_Command.prototype.commandName = function(index) {
    return DKTools.Localization.getText(
        this.convertEscapeCharacters(Localization_Window_Command_commandName.apply(this, arguments)));
};

//=============================================================================
// Window_TitleCommand
//=============================================================================

const Localization_Window_TitleCommand_makeCommandList =
    Window_TitleCommand.prototype.makeCommandList;
Window_TitleCommand.prototype.makeCommandList = function() {
    Localization_Window_TitleCommand_makeCommandList.apply(this, arguments);

    if (LocalizationParam.get('Show Command')) {
        this.addLocaleCommand();
    }
};

Window_TitleCommand.prototype.addLocaleCommand = function() {
    this.addCommand(LocalizationParam.get('Command Name'), 'locale');
};

//===========================================================================
// Window_NameEdit
//===========================================================================

const Localization_Window_NameEdit_initialize =
    Window_NameEdit.prototype.initialize;
Window_NameEdit.prototype.initialize = function(actor, maxLength) {
    Localization_Window_NameEdit_initialize.apply(this, arguments);
    this._name = DKTools.Localization.getText(this._name).slice(0, this._maxLength);
    this._index = this._name.length;
};

//===========================================================================
// Window_Options
//===========================================================================

const Localization_Window_Options_makeCommandList =
    Window_Options.prototype.makeCommandList;
Window_Options.prototype.makeCommandList = function() {
    Localization_Window_Options_makeCommandList.apply(this, arguments);

    if (!Imported['YEP_OptionsCore'] && LocalizationParam.get('Show Options Command')) {
        this.addLocaleCommand();
    }
};

Window_Options.prototype.addLocaleCommand = function() {
    this.addCommand(LocalizationParam.get('Options Command Name'), 'locale');
};

const Localization_Window_Options_statusText =
    Window_Options.prototype.statusText;
Window_Options.prototype.statusText = function(index) {
    if (this.commandSymbol(index) === 'locale') {
        return DKTools.Localization.language;
    }

    return Localization_Window_Options_statusText.apply(this, arguments);
};

const Localization_Window_Options_booleanStatusText =
    Window_Options.prototype.booleanStatusText;
Window_Options.prototype.booleanStatusText = function(value) {
    if (LocalizationParam.get('Rename Options Text')) {
        return value ? LocalizationParam.get('Options ON Text')
            : LocalizationParam.get('Options OFF Text');
    }

    return Localization_Window_Options_booleanStatusText.apply(this, arguments);
};

const Localization_Window_Options_getConfigValue =
    Window_Options.prototype.getConfigValue;
Window_Options.prototype.getConfigValue = function(symbol) {
    if (symbol === 'locale') {
        return DKTools.Localization.locale;
    }

    return Localization_Window_Options_getConfigValue.apply(this, arguments);
};

const Localization_Window_Options_setConfigValue =
    Window_Options.prototype.setConfigValue;
Window_Options.prototype.setConfigValue = function(symbol, volume) {
    if (symbol === 'locale') {
        DKTools.Localization.selectNextLocale().then(() => {
            if (SceneManager.isCurrentScene(Scene_Options)) {
                SceneManager._scene.onLocaleChange();
            } else {
                this.refresh();
            }
        });
    } else {
        Localization_Window_Options_setConfigValue.apply(this, arguments);
    }
};

//===========================================================================
// Window_MessageLanguageSwitcher
//===========================================================================

class Window_MessageLanguageSwitcher extends Window_Command {

    initialize() {
        const x = LocalizationParam.get('Message Switcher X') || 0;
        const y = LocalizationParam.get('Message Switcher Y') || 0;

        this._windowWidth = LocalizationParam.get('Message Switcher Width') || 400;

        super.initialize(x, y);

        this.selectExt(DKTools.Localization.locale);
        this.hide();
        this.close();
    }

    windowWidth() {
        return this._windowWidth;
    }

    windowHeight() {
        return this.fittingHeight(1);
    }

    maxCols() {
        return DKTools.Localization.locales.length;
    }

    makeCommandList() {
        DKTools.Localization.locales.forEach((locale) => {
            this.addCommand(locale, locale, true, locale);
        });
    }

    setMessageWindow(window) {
        this._messageWindow = window;
    }

    setChoiceWindow(window) {
        this._choiceWindow = window;
    }

    select(index) {
        const lastIndex = this._index;

        super.select(index);

        if (this._messageWindow && this._messageWindow.isOpen()) {
            if (index >= 0 && index !== lastIndex) {
                DKTools.Localization.selectLocale(this.currentExt()).then(() => {
                    const originalTexts = $gameMessage.getOriginalTexts();
                    const originalChoices = $gameMessage.getOriginalChoices();
                    const defaultType = $gameMessage.choiceDefaultType();
                    const cancelType = $gameMessage.choiceCancelType();

                    if ($gameMessage.isChoice()) {
                        this._choiceWindow.openness = 0;
                        this._choiceWindow.deactivate();
                    }

                    this._messageWindow.terminateMessage();
                    this._messageWindow.pause = false;
                    this._messageWindow.openness = 0;
                    this._messageWindow.update();

                    originalTexts.forEach((text) => {
                        $gameMessage.add(text);
                    });

                    $gameMessage.setChoices(originalChoices, defaultType, cancelType);

                    this._messageWindow.startMessage();
                });
            }
        }
    }

    needsClose() {
        if ($gameMessage.isNumberInput() || $gameMessage.isItemChoice()) {
            return true;
        }

        if (this._messageWindow) {
            if (this._messageWindow.isClosed() || this._messageWindow.isClosing()) {
                return true;
            }
        }

        return false;
    }

    update() {
        super.update();

        if (this.needsClose()) {
            this.openness = 0;
            this.active = false;
        } else {
            const keyCode = LocalizationParam.get('Message Switcher Button');
            const button = Input.keyMapper[keyCode];

            if (Input.isTriggered(button)) {
                if (this.isOpen()) {
                    this.close();
                } else {
                    this.show();
                    this.open();
                }
            }

            this.active = this.isOpen();
        }
    }

}

//===========================================================================
// Scene_Boot
//===========================================================================

Scene_Boot.prototype.updateDocumentTitle = function() {
    DKTools.Localization.updateGameTitle();
};

//===========================================================================
// Scene_Map
//===========================================================================

const Localization_Scene_Map_createAllWindows = Scene_Map.prototype.createAllWindows;
Scene_Map.prototype.createAllWindows = function() {
    Localization_Scene_Map_createAllWindows.apply(this, arguments);
    this.createLanguageSwitcherWindow();
};

Scene_Map.prototype.createLanguageSwitcherWindow = function() {
    if (!Utils.isTest()) {
        return;
    }

    this._languageSwitcherWindow = new Window_MessageLanguageSwitcher();
    this._languageSwitcherWindow.setMessageWindow(this._messageWindow);
    this._languageSwitcherWindow.setChoiceWindow(this._messageWindow._choiceWindow);

    this.addWindow(this._languageSwitcherWindow);
};

//=============================================================================
// Scene_Title
//=============================================================================

const Localization_Scene_Title_create = Scene_Title.prototype.create;
Scene_Title.prototype.create = function() {
    Localization_Scene_Title_create.apply(this, arguments);

    if (this.needsSelectLanguage()) {
        SceneManager.goto(Scene_SelectLanguage);
        SceneManager.prepareNextScene(Scene_Title, { firstLaunch: true });

        return;
    }

    if (LocalizationParam.get('Show Button')) {
        this.createLocalizationButton();
    }
};

const Localization_Scene_Title_createCommandWindow =
    Scene_Title.prototype.createCommandWindow;
Scene_Title.prototype.createCommandWindow = function() {
    Localization_Scene_Title_createCommandWindow.apply(this, arguments);

    if (LocalizationParam.get('Show Command')) {
        this._commandWindow.setHandler('locale', this.onCommandLocale);
    }
};

Scene_Title.prototype.createLocalizationButton = function() {
    const x = LocalizationParam.get('Button X');
    const y = LocalizationParam.get('Button Y');
    const filename = LocalizationParam.get('Button Graphic')
                                       .format(DKTools.Localization.locale);

    this._localizationButton = new DKTools.Sprite.Button(x, y);
    this._localizationButton.loadSystem(filename);
    this._localizationButton.setupAnchor(0.5, 0.5);
    this._localizationButton.start(true);

    this._localizationButton.addEvent({
        type: 'state-pressed',
        onUpdate: function() {
            this.opacity = 200;
            this.scale.set(0.95, 0.95);
        }.bind(this._localizationButton)
    });

    this._localizationButton.addEvent({
        type: 'state-normal',
        onUpdate: function() {
            this.opacity = 255;
            this.scale.set(1, 1);
        }.bind(this._localizationButton)
    });

    this._localizationButton.addEvent({
        type: 'mouse-click-left',
        onUpdate: this.onCommandLocale.bind(this)
    });

    this._localizationButton.addEvent({
        type: 'touch',
        onUpdate: this.onCommandLocale.bind(this)
    });

    this._localizationButton.addOneTimeEvent({
        type: 'ready',
        onSuccess: function() {
            this.move(x + this.width / 2, y + this.height / 2);
        }.bind(this._localizationButton)
    });

    this.addChild(this._localizationButton);
};

Scene_Title.prototype.onCommandLocale = function() {
    SceneManager.push(Scene_SelectLanguage);
};

Scene_Title.prototype.needsSelectLanguage = function() {
    return LocalizationParam.get('First Launch') &&
        !DKTools.Localization.isLocaleFileExists();
};

//===========================================================================
// Scene_Options
//===========================================================================

Scene_Options.prototype.onLocaleChange = function() {
    if (this._optionsWindow) {
        this._optionsWindow.refresh();
    }

    if (Imported['YEP_OptionsCore']) {
        if (this._categoryWindow) {
            this._categoryWindow.refresh();
        }

        if (this._helpWindow) {
            this._helpWindow.refresh();
        }
    }
};

//===========================================================================
// Scene_SelectLanguage
//===========================================================================

function Scene_SelectLanguage() {
    this.initialize.apply(this, arguments);
}

Scene_SelectLanguage.prototype = Object.create(DKTools.Scene.prototype);
Scene_SelectLanguage.prototype.constructor = Scene_SelectLanguage;

// initialize

Scene_SelectLanguage.prototype.initialize = function() {
    DKTools.Scene.prototype.initialize.apply(this, arguments);
    this._locales = DKTools.Localization.locales;
    this._style = LocalizationParam.get('Style') || 'Window';
    this._styleOptions = LocalizationParam.get(`Style ${this._style}`) || {};
    this._options = {};
};

// prepare

Scene_SelectLanguage.prototype.prepare = function(nextScene, options = {}) {
    this._nextScene = nextScene;
    this._options = options;
};

// preloading methods

Scene_SelectLanguage.prototype.setupPreloading = function() {
    DKTools.Scene.prototype.setupPreloading.apply(this, arguments);

    const flagName = LocalizationParam.get('Flag Filename');
    const promises = DKTools.Localization.locales.map((locale) => {
        return DKTools.Utils.Bitmap.loadAsync({
            folder: 'img/system/',
            filename: flagName.format(locale)
        });
    });

    this._preloader.add(Promise.all(promises));
};

// create methods

Scene_SelectLanguage.prototype.createBackground = function() {
    const background = LocalizationParam.get('Background Filename');

    if (!background) {
        return;
    }

    this._background = new DKTools.Sprite();
    this._background.setupGraphicName(background);
    this._background.start();

    this.addChild(this._background);
};

Scene_SelectLanguage.prototype.createAllSprites = function() {
    if (this._style === 'Flags') {
        this.createFlags();
    }
};

Scene_SelectLanguage.prototype.createAllWindows = function() {
    if (this._style === 'Window') {
        this.createLanguageWindow();

        if (this._styleOptions['Help Window']['Show']) {
            this.createHelpWindow();
        }
    } else if (this._style === 'Flags') {
        if (this._styleOptions['Help Window']['Show']) {
            this.createHelpWindow();
        }

        if (this._styleOptions['Language Window']['Show']) {
            this.createLanguageNameWindow();
        }
    }
};

Scene_SelectLanguage.prototype.createLanguageWindow = function() {
    const flagName = LocalizationParam.get('Flag Filename');
    const fontSize = LocalizationParam.get('Font Size');
    const rowHeight = this._styleOptions['Row Height'];
    const items = this._locales.map(locale => ({
        name: DKTools.Localization.getLanguageByLocale(locale),
        symbol: 'ok',
        handler: this.onLanguageOk.bind(this),
        ext: locale
    }));

    this._languageWindow = new DKTools.Window.Selectable();

    this._languageWindow.setupItems(items);
    this._languageWindow.setupItemHeight(rowHeight);
    this._languageWindow.setupItemDrawHandler(function(index) {
        const language = this.itemName(index);
        const locale = this.itemExt(index);
        const rect = this.itemRectForText(index);
        const flag = ImageManager.loadSystem(flagName.format(locale));

        flag.addLoadListener(() => {
            const x = rect.x + flag.width + 4;

            this.drawBitmap(flag, {
                destination: {
                    x: rect.x,
                    y: rect.y + Math.max(0, (rect.height - flag.height) / 2),
                    height: flag.height
                }
            });

            this.contents.fontSize = fontSize;
            this.contents.drawText(language, x, rect.y, rect.width - x, rect.height, 'left');
        });
    }.bind(this._languageWindow));

    this._languageWindow.setupSize(
        this._styleOptions['Window Width'],
        String(Math.min(this._styleOptions['Window Rows'], this._locales.length)));

    this._languageWindow.move(
        (Graphics.boxWidth - this._languageWindow.width) / 2,
        (Graphics.boxHeight - this._languageWindow.height) / 2);

    if (!this._options.firstLaunch) {
        this._languageWindow.setHandler('cancel', this.onLanguageCancel.bind(this));
    }

    this._languageWindow.addEvent({
        type: 'select',
        onUpdate: () => {
            const locale = this._languageWindow.currentExt();

            if (this._helpWindow) {
                this._helpWindow.refreshAll();
            }

            this.refreshBackground(locale);
            this.refreshForeground(locale);
        }
    });

    this._languageWindow.start(true);

    this.addWindow(this._languageWindow);
};

Scene_SelectLanguage.prototype.createFlags = function() {
    const flagName = LocalizationParam.get('Flag Filename');

    this._flagSprites = this._locales.map((locale, index) => {
        const sprite = new DKTools.Sprite.Button();
        const selectHandler = function() {
            if (this._index === sprite.id) {
                if (this._styleOptions['Play Ok Sound']) {
                    SoundManager.playOk();
                }

                this.onLanguageOk();
            } else {
                if (this._styleOptions['Play Cursor Sound']) {
                    SoundManager.playCursor();
                }

                this.selectFlag(sprite.id);
            }
        }.bind(this);

        sprite.id = index;
        sprite.anchor.set(0.5, 0.5);
        sprite.setupGraphicName(flagName.format(locale));

        sprite.addEvent({
            type: 'mouse-click-left',
            onUpdate: selectHandler
        });

        sprite.addEvent({
            type: 'touch',
            onUpdate: selectHandler
        });

        sprite.start(true);

        return sprite;
    });

    this.addChild(...this._flagSprites);
    this.selectFlag(0);
};

Scene_SelectLanguage.prototype.createHelpWindow = function() {
    const fontSize = LocalizationParam.get('Font Size');
    const params = this._styleOptions['Help Window'];
    const width = eval(params['Width']);
    const x = (Graphics.boxWidth - width) / 2;
    const y = eval(params['Y']);
    const height = '1';

    this._helpWindow = new DKTools.Window(x, y, width, height);

    this._helpWindow.contentsSprite.setupFont({ fontSize });

    this._helpWindow.addEvent({
        type: 'draw-all',
        onUpdate: () => {
            const index = (this._style === 'Window' ?
                this._languageWindow.index() : this._index);
            const locale = this._locales[index];
            const helpText = DKTools.Localization.getHelpText(locale);

            if (!helpText) {
                throw new Error(`Could not find help text for the locale: ${locale}`);
            }

            this._helpWindow.drawText(helpText);
        }
    });

    if (!params['Show Frame']) {
        this._helpWindow.hideFrame();
    }

    if (params['Background Opacity'] > 0) {
        this._helpWindow.backOpacity = params['Background Opacity'];
    } else if (params['Background Opacity'] === 0) {
        this._helpWindow.hideBack();
    }

    this._helpWindow.start();

    this.addWindow(this._helpWindow);
};

Scene_SelectLanguage.prototype.createLanguageNameWindow = function() {
    const fontSize = LocalizationParam.get('Font Size');
    const params = this._styleOptions['Language Window'];
    const width = eval(params['Width']);
    const x = (Graphics.boxWidth - width) / 2;
    const y = eval(params['Y']);
    const height = '1';

    this._languageNameWindow = new DKTools.Window(x, y, width, height);

    this._languageNameWindow.contentsSprite.setupFont({ fontSize });

    this._languageNameWindow.addEvent({
        type: 'draw-all',
        onUpdate: () => {
            const language = DKTools.Localization.getLanguageByLocale(
                this._locales[this._index]);

            this._languageNameWindow.drawText(language);
        }
    });

    if (!params['Show Frame']) {
        this._languageNameWindow.hideFrame();
    }

    if (params['Background Opacity'] > 0) {
        this._languageNameWindow.backOpacity = params['Background Opacity'];
    } else if (params['Background Opacity'] === 0) {
        this._languageNameWindow.hideBack();
    }

    this._languageNameWindow.start();

    this.addWindow(this._languageNameWindow);
};

Scene_SelectLanguage.prototype.createForeground = function() {
    const foreground = LocalizationParam.get('Foreground Filename');

    if (!foreground) {
        return;
    }

    this._foreground = new DKTools.Sprite();
    this._foreground.setupGraphicName(foreground);
    this._foreground.start();

    this.addChild(this._foreground);
};

// start methods

Scene_SelectLanguage.prototype.start = function() {
    DKTools.Scene.prototype.start.apply(this, arguments);

    if (this._options.firstLaunch) {
        const type = LocalizationParam.get('First Launch Cursor') || 'auto';
        let locale;

        if (type === 'auto') {
            locale = this._locales.find(
                locale => locale === window.navigator.language
                    || window.navigator.language.match(new RegExp(`^${locale}`)));
        } else if (type === 'primary') {
            locale = DKTools.Localization.getPrimaryLocale();
        }

        if (locale) {
            if (this._style === 'Window') {
                this._languageWindow.selectExt(locale);
            } else {
                const index = this._locales.indexOf(locale);

                if (this._index !== index) {
                    this.selectFlag(index);
                }
            }
        }
    } else {
        if (this._style === 'Window') {
            this._languageWindow.selectExt(DKTools.Localization.locale);
        } else {
            const index = this._locales.indexOf(DKTools.Localization.locale);

            if (this._index !== index) {
                this.selectFlag(index);
            }
        }
    }

    const bgm = LocalizationParam.get('BGM');

    if (bgm && bgm['BGM']) {
        AudioManager.playBgm({
            name: bgm['BGM'],
            volume: bgm['Volume'] || 90,
            pan: bgm['Pan'] || 0,
            pitch: bgm['Pitch'] || 100
        });
    }
};

// get methods

Scene_SelectLanguage.prototype._getFlagAnimation = function(sprite) {
    const options = this._styleOptions['Flag Animation']
    const repeatTime = options['Duration'];
    const animation = new DKTools.Animation({
        type: 'update',
        repeatTime
    });

    animation.addAction(DKTools.Animation.Action.Scale({
        target: sprite,
        startTime: 0,
        endTime: repeatTime / 2,
        data: new Point(options['Min Scale'], options['Min Scale'])
    }));

    animation.addAction(DKTools.Animation.Action.Scale({
        target: sprite,
        startTime: repeatTime / 2,
        endTime: repeatTime,
        data: new Point(options['Max Scale'], options['Max Scale'])
    }));

    return animation;
};

// handler methods

Scene_SelectLanguage.prototype.onLanguageOk = function() {
    if (this._style === 'Window') {
        DKTools.Localization.selectLocale(this._languageWindow.currentExt());
    } else {
        DKTools.Localization.selectLocale(this._locales[this._index]);
    }

    this.fadeOutAll();
    this.popScene();
};

Scene_SelectLanguage.prototype.onLanguageCancel = function() {
    this.fadeOutAll();
    this.popScene();
};

Scene_SelectLanguage.prototype.popScene = function() {
    if (this._nextScene) {
        SceneManager.goto(this._nextScene);
    } else {
        DKTools.Scene.prototype.popScene.apply(this, arguments);
    }
};

Scene_SelectLanguage.prototype.selectFlag = function(index) {
    this._index = index;

    if (this._helpWindow) {
        this._helpWindow.refreshAll();
    }

    if (this._languageNameWindow) {
        this._languageNameWindow.refreshAll();
    }

    this.refreshBackground(this._locales[index]);
    this.refreshForeground(this._locales[index]);
    this.updateFlagsPlacement();
};

Scene_SelectLanguage.prototype.refreshBackground = function(locale) {
    if (this._background) {
        const filename = LocalizationParam.get('Background Filename');

        DKTools.Utils.Bitmap.load({
            folder: DKTools.Localization.getImageFolder(
                'img/system/', filename, locale),
            filename,
            listener: (bitmap) => {
                this._background.setBitmap(bitmap);
            }
        });
    }
};

Scene_SelectLanguage.prototype.refreshForeground = function(locale) {
    if (this._foreground) {
        const filename = LocalizationParam.get('Foreground Filename');

        DKTools.Utils.Bitmap.load({
            folder: DKTools.Localization.getImageFolder(
                'img/system/', filename, locale),
            filename,
            listener: (bitmap) => {
                this._foreground.setBitmap(bitmap);
            }
        });
    }
};

Scene_SelectLanguage.prototype.updateFlagsPlacement = function() {
    this._flagSprites.forEach(sprite => sprite.hide());

    const animationOptions = this._styleOptions['Flag Animation'] || {};
    const central = this._flagSprites[this._index];
    const scale = new Point(
        this._styleOptions['Side Flags']['Scale'], this._styleOptions['Side Flags']['Scale']);
    const opacity = this._styleOptions['Side Flags']['Opacity'];

    central.show(true);
    central.scale.set(1, 1);
    central.opacity = 255;
    central.move(Graphics.boxWidth / 2, Graphics.boxHeight / 2);

    if (animationOptions['Enabled']) {
        if (this._animation) {
            this._animation.finish(true);
        }

        this._animation = this._getFlagAnimation(central);
        this._eventsManager.addAnimation(this._animation);
    }

    let showLeft = false;
    let showRight = false;

    if (this._styleOptions['Loop Scroll'] && this._locales.length > 2) {
        showLeft = true;
        showRight = true;
    } else if (this._index === 0) {
        showRight = true;
    } else if (this._index === DKTools.Localization.locales.length - 1) {
        showLeft = true;
    } else {
        showLeft = true;
        showRight = true;
    }

    if (showLeft) {
        let left = this._flagSprites[this._index - 1];

        if (!left && this._styleOptions['Loop Scroll'] && this._locales.length > 2) {
            left = this._flagSprites[this._locales.length - 1];
        }

        if (left) {
            left.show(true);

            left.scale.copy(scale);
            left.opacity = opacity;

            const x = eval(this._styleOptions['Side Flags']['Left Flag X']);
            const y = Graphics.boxHeight / 2;

            left.move(x, y);
        }
    }

    if (showRight) {
        let right = this._flagSprites[this._index + 1];

        if (!right && this._styleOptions['Loop Scroll'] && this._locales.length > 2) {
            right = this._flagSprites[0];
        }

        if (right) {
            right.show(true);

            right.scale.copy(scale);
            right.opacity = opacity;

            const x = eval(this._styleOptions['Side Flags']['Right Flag X']);
            const y = Graphics.boxHeight / 2;

            right.move(x, y);
        }
    }
};

Scene_SelectLanguage.prototype.updateFlagsInput = function() {
    if (this._style === 'Window') {
        return;
    }

    const scrollRight = (Input.isRepeated('right')
        || this._styleOptions['Mouse Scroll'] && TouchInput.wheelY > 0)
        && (this._index < DKTools.Localization.locales.length - 1 || this._styleOptions['Loop Scroll']);

    const scrollLeft = (Input.isRepeated('left') ||
        this._styleOptions['Mouse Scroll'] && TouchInput.wheelY < 0)
        && (this._index > 0 || this._styleOptions['Loop Scroll']);

    if (scrollRight) {
        if (this._styleOptions['Play Cursor Sound']) {
            SoundManager.playCursor();
        }

        if (this._index + 1 < this._locales.length) {
            this.selectFlag(this._index + 1);
        } else {
            this.selectFlag(0);
        }
    } else if (scrollLeft) {
        if (this._styleOptions['Play Cursor Sound']) {
            SoundManager.playCursor();
        }

        if (this._index > 0) {
            this.selectFlag(this._index - 1);
        } else {
            this.selectFlag(this._locales.length - 1);
        }
    } else if (Input.isTriggered('ok')) {
        if (this._styleOptions['Play Ok Sound']) {
            SoundManager.playOk();
        }

        this.onLanguageOk();
    } else if (!this._options.firstLaunch && (Input.isTriggered('cancel') || TouchInput.isCancelled())) {
        if (this._styleOptions['Play Cancel Sound']) {
            SoundManager.playCancel();
        }

        this.onLanguageCancel();
    }
};

Scene_SelectLanguage.prototype.update = function() {
    DKTools.Scene.prototype.update.apply(this, arguments);

    if (!this.isBusy()) {
        this.updateFlagsInput();
    }
};

//===========================================================================
// Compatibility with other plugins
//===========================================================================

if (Imported['YEP_MessageCore']) {

    Game_System.prototype.initMessageFontSettings = function() {
        if (this.isChinese()) {
            this._msgFontName = Yanfly.Param.MSGCNFontName;
        } else if (this.isKorean()) {
            this._msgFontName = Yanfly.Param.MSGKRFontName;
        } else {
            this._msgFontName = Yanfly.Param.MSGFontName;
        }

        this._msgFontSize = Yanfly.Param.MSGFontSize;
        this._msgFontOutline = Yanfly.Param.MSGFontOutline;
    };

    const Localization_Window_Message_convertNameBox = Window_Message.prototype.convertNameBox;
    Window_Message.prototype.convertNameBox = function(text) {
        text = text.replace(/\x1bMN\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 1);
        }, this);
        text = text.replace(/\x1bMN1\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 1);
        }, this);
        text = text.replace(/\x1bMN2\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 2);
        }, this);
        text = text.replace(/\x1bMN3\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 3);
        }, this);
        text = text.replace(/\x1bMNC\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 3);
        }, this);
        text = text.replace(/\x1bMN4\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 4);
        }, this);
        text = text.replace(/\x1bMN5\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 5);
        }, this);
        text = text.replace(/\x1bMNR\<(.*?)\>/gi, function() {
            return Yanfly.nameWindow.refresh(arguments[1], 5);
        }, this);

        return Localization_Window_Message_convertNameBox.call(this, text);
    };

    DKTools.Localization.addChangeLocaleListener(() => {
        $gameSystem.initMessageFontSettings();
    });

}

if (Imported['YEP_QuestJournal']) {

    const Localization_Window_QuestData_drawQuestTextEx = Window_QuestData.prototype.drawQuestTextEx;
    Window_QuestData.prototype.drawQuestTextEx = function(text, x, y) {
        return Localization_Window_QuestData_drawQuestTextEx.call(
            this, DKTools.Localization.getText(text), x, y);
    };

}

if (Imported['CGMV_Encyclopedia']) {

    const Localization_CGMV_Encyclopedia_prototype_initializeData =
        CGMV_Encyclopedia.prototype.initializeData;
    CGMV_Encyclopedia.prototype.initializeData = function(array, length, symbol) {
        CGMV.Encyclopedia.HalfEncounterText = DKTools.Localization.getText(CGMV.Encyclopedia.HalfEncounterText);
        CGMV.Encyclopedia.NoEncounterText = DKTools.Localization.getText(CGMV.Encyclopedia.NoEncounterText);
        CGMV.Encyclopedia.CancelSurpriseText = DKTools.Localization.getText(CGMV.Encyclopedia.CancelSurpriseText);
        CGMV.Encyclopedia.RaisePreemptiveText = DKTools.Localization.getText(CGMV.Encyclopedia.RaisePreemptiveText);
        CGMV.Encyclopedia.GoldDoubleText = DKTools.Localization.getText(CGMV.Encyclopedia.GoldDoubleText);
        CGMV.Encyclopedia.DropItemDoubleText = DKTools.Localization.getText(CGMV.Encyclopedia.DropItemDoubleText);
        Localization_CGMV_Encyclopedia_prototype_initializeData.apply(this, arguments);
    };

    const Localization_CGMV_Window_EncyclopediaDisplay_drawEncyclopediaMeta =
        CGMV_Window_EncyclopediaDisplay.prototype.drawEncyclopediaMeta;
    CGMV_Window_EncyclopediaDisplay.prototype.drawEncyclopediaMeta = function(meta, y) {
        return Localization_CGMV_Window_EncyclopediaDisplay_drawEncyclopediaMeta.call(
            this, DKTools.Localization.getText(meta), y);
    };

    const Localization_CGMV_Window_EncyclopediaDisplay_drawEncyclopediaDescription =
        CGMV_Window_EncyclopediaDisplay.prototype.drawEncyclopediaDescription;
    CGMV_Window_EncyclopediaDisplay.prototype.drawEncyclopediaDescription = function(description, y) {
        return Localization_CGMV_Window_EncyclopediaDisplay_drawEncyclopediaDescription.call(
            this, DKTools.Localization.getText(description), y);
    };

}
